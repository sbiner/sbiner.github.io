/* Progamme pour tester le parametrage de GT
 */

import javax.swing.* ;
import java.lang.Math.* ;
import org.jfree.chart.* ;
import org.jfree.data.* ;
import java.awt.* ;
import java.io.File ;
import java.awt.image.BufferedImage ;
import org.jfree.chart.plot.PlotOrientation ;


public class T2JFreeChart extends JFrame{ 

	 public static void main (String args []) throws Exception {
		  T2JFreeChart test = new T2JFreeChart() ;
	 } // fin du main

	 public T2JFreeChart () throws Exception
	 {

		  /* panel avec les boutons */
		  JPanel jpControle = new JPanel() ;
		  creerPanelControle(jpControle) ;


		  /* panel avec le graphique */
		  // creation du chart et placage dans un panel
		  JFreeChart chart = creerChart() ;
		  // ecriture du chart en image
		  ChartUtilities.saveChartAsJPEG(new File("chart.jpg"),chart,500,300);
		  // on creer l'image en buffer et on la met dans un Label
		  BufferedImage image = chart.createBufferedImage(500,300) ;
		  JLabel lblChart = new JLabel() ;
		  lblChart.setIcon(new ImageIcon(image)) ;
		  
		  this.getContentPane().setLayout(new BorderLayout()) ;
		  this.setSize(800,500) ;		  
		  this.getContentPane().add(jpControle,BorderLayout.NORTH) ;
		  this.getContentPane().add(jpControle,BorderLayout.CENTER) ;
		  this.getContentPane().add(jpControle,BorderLayout.SOUTH) ;

		  //		  this.getContentPane().add(lblChart) ;
		  
		  this.setVisible(true);

	 }// fin TestJFreeChart

	 public void creerPanelControle(JPanel p) {

		  JButton jbredessine = new JButton("redessiner") ;
		  JLabel jlfrequence = new JLabel("frequence") ;
		  JTextField jtffrequence = new JTextField("10") ;
		  p.add(jbredessine) ;
		  p.add(jlfrequence) ;
		  p.add(jtffrequence) ;


	 } // fin creerPanelControle




	 public JFreeChart creerChart() {
		  XYSeries serie1 = new XYSeries("serie de points");
		  serie1.add(1,3) ;
		  serie1.add(2,2) ;
		  serie1.add(3,1) ;
		  XYDataset xyDataset = new XYSeriesCollection(serie1);
		  return ChartFactory.createXYAreaChart("exemple the XY area",
															 "axe x",
															 "axe y",
															 xyDataset,
															 PlotOrientation.HORIZONTAL,
															 false,
															 false,
															 false) ;
	 } // fin de creerChart
} // fin de TestJFreeChart
