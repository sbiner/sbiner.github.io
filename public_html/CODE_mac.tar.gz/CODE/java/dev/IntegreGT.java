/* Progamme pour tester le parametrage de GT
 */

import javax.swing.* ;
import java.lang.Math.* ;
import gov.noaa.pmel.sgt.* ;
import gov.noaa.pmel.sgt.swing.* ;
import gov.noaa.pmel.sgt.dm.* ;

public class IntegreGT { 

	 public static void main (String args []) {		  

		  // initialisation des parametres

		  final int nmax = 96*5 ;
		  final double delt = 900 ,
				pi=java.lang.Math.PI,
				w=2*pi ,
				s=1000.,
				sbc=5.67E-08,
				C=10E3,
				alpha1=w/24/3600*delt,
				alpha2=w/24/3600/30*delt,
				gtini=283 ;

		  // initialisation des variables

		  double gt [] = new double [nmax] ;
		  double gta1 [] = new double [nmax] ;
		  double gta2 [] = new double [nmax] ;
		  int n = 0 ;

		  // boucle d'integration
		  
		  for (n=0;n<nmax;n++) {
				if (n == 0) {
					 gt[n]=gta1[n]=gta2[n]=gtini ;
					 print("gt="+gt[n]) ;
					 print("gta1="+gta1[n]) ;
					 print("gta2="+gta2[n]) ;
				}
				else {
					 gt[n]=gtini*Math.sin(w*n/24) ;
					 //print("n="+n+" gt="+gt[n]);
				}
		  }

		  // ouverture du JFrame

		  JFrame frame1 = new JFrame() ;

		  // ouverture de JPlotLayout  et ajout au frame
		  JPlotLayout layout = new JPlotLayout(false,false,false,"test",null,false) ;
		  frame1.getContentPane().add(layout) ;
		  frame1.pack() ;
		  frame1.setVisible(true) ;


		  // ajout d'un panel de bouton au frame
		  JPanel panel1 = new JPanel() ;
		  JButton bouton1 = new JButton("bouton#1") ;
		  frame1.getContentPane().add(panel1) ;
		  panel1.add(bouton1) ;

		  // ajout des lignes sur le Layout
		  layout.setBatch(true) ;
		  
		  
		  // preparation des coord de la ligne
		  
		  double [] x = new double [3] ;
		  double [] y = new double [3] ;
		  x[0]=1 ; x[1]=2 ; x[2]=3 ;
		  y[0]=1 ; y[1]=2 ; y[2]=3 ;

		  SimpleLine ligne1 = new SimpleLine(x,y,"test") ;
		  SGTData data = ligne1 ;

		  print(data.getTitle()) ;

		  layout.addData(data) ;

		  //layout.addData(data) ;
		  
		  layout.setBatch(false) ;

	 } // fin du main

	 /*
	 public static SGTLine creerLigne(double gt[],int  nmax) {
		  double [] x = new double [nmax] ;
		  double [] y = new double [nmax];
		  int n ;
		  for (n=0;n<nmax;n++) {
				x[n]=n ;
				y[n]=gt[n] ;
				print("n="+n+"   x,y="+x[n]+","+y[n]) ;

		  }
		  SimpleLine ligne1 = new SimpleLine(x,y,"example") ;
		  ligne1.setId("example") ;
		  return ligne1 ;
		  

	 } // fin creerLigne
	 */




	 // methode pour imprimer une chaine de characteres

	 static void print(String x) {
		  System.out.println(x) ;
	 }

}
