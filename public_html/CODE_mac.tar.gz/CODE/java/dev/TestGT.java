/* Progamme pour tester le parametrage de GT
 */

import javax.swing.* ;

class IntegreGT { 

	 public static void main (String args []) {

		  System.out.println("debut") ;
		  affichePI() ;

		  System.out.println("fin") ;		  

	 }

	 static  void affichePI() {
		  System.out.println("Pi="+java.lang.Math.PI) ;
	 }

}
