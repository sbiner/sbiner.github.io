/* Progamme pour tester le parametrage de GT
 */

import javax.swing.* ;
import java.lang.Math.* ;
import gov.noaa.pmel.sgt.* ;
import gov.noaa.pmel.sgt.swing.* ;
import gov.noaa.pmel.sgt.dm.* ;

public class TestSGT { 

	 public static void main (String args []) {		  

		  // ouverture du JFrame
		  
		  JFrame frame1 = new JFrame() ;

		  // ouverture de JPlotLayout  et ajout au frame
		  JPlotLayout layout = new JPlotLayout(false,false,false,"test",null,false) ;
		  frame1.getContentPane().add(layout) ;
		  frame1.pack() ;
		  frame1.setVisible(true) ;

		  // preparation des coord de la ligne
		  
		  double [] x = new double [3] ;
		  double [] y = new double [3] ;
		  x[0]=1 ; x[1]=2 ; x[2]=3 ;
		  y[0]=1 ; y[1]=2 ; y[2]=3 ;

		  SimpleLine ligne1 = new SimpleLine(x,y,"test") ;
		  SGTData data = ligne1 ;

		  print("titre="+data.getTitle()) ;

		  // ajout des lignes sur le Layout
		  layout.setBatch(true) ;
		  layout.addData(data) ;
		  layout.setBatch(false) ;

	 } // fin du main


	 // methode pour imprimer une chaine de characteres

	 static void print(String x) {
		  System.out.println(x) ;
	 }

}
