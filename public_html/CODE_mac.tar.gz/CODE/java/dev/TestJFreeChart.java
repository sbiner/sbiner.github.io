/* Progamme pour tester le parametrage de GT
 */

import javax.swing.* ;
import java.lang.Math.* ;
import org.jfree.chart.* ;
import org.jfree.data.* ;
import java.awt.* ;
import java.io.File ;
import java.awt.image.BufferedImage ;
import org.jfree.chart.plot.PlotOrientation ;


public class TestJFreeChart extends JFrame{ 

	 public static void main (String args []) throws Exception {
		  TestJFreeChart test = new TestJFreeChart() ;
	 } // fin du main

	 public TestJFreeChart () throws Exception
	 {

		  /*** panel avec les boutons ***/
		  Jpanel panelcontrole = new JPanel ;
		  


		  /*** panel avec le graphique *** /
		  // creation du chart et placage dans un panel
		  JFreeChart chart = creerChart() ;
		  // ecriture du chart en image
		  ChartUtilities.saveChartAsJPEG(new File("chart.jpg"),chart,500,300);
		  // on creer l'image en buffer et on la met dans un Label
		  BufferedImage image = chart.createBufferedImage(500,300) ;
		  JLabel lblChart = new JLabel() ;
		  lblChart.setIcon(new ImageIcon(image)) ;
		  





		  this.getContentPane().setLayout(new BorderLayout()) ;
		  this.getContentPane().add(lblChart) ;
		  this.setSize(600,400) ;
		  this.setVisible(true);

	 }// fin TestJFreeChart

	 public JFreeChart creerChart() {
		  XYSeries serie1 = new XYSeries("serie de points");
		  serie1.add(1,3) ;
		  serie1.add(2,2) ;
		  serie1.add(3,1) ;
		  XYDataset xyDataset = new XYSeriesCollection(serie1);
		  return ChartFactory.createXYAreaChart("exemple the XY area",
															 "axe x",
															 "axe y",
															 xyDataset,
															 PlotOrientation.HORIZONTAL,
															 false,
															 false,
															 false) ;
	 } // fin de creerChart
} // fin de TestJFreeChart
