package sdsu;

/**
 * This string formatting class emulates some of the functionality of the
 * the standard C library sprintf() function.  Since Java doesn't allow for
 * a variable number of arguments of anonymous types, the formatting has
 * been split up into several <i>format</i> member functions with different.
 * arguments.<p>
 *
 * Some example uses of this class:<pre>
 * sdsu.FormatString.format("'%5d'", 42)      gives '   42'
 * sdsu.FormatString.format("'%-10s'", "hi")  gives 'hi        '
 * sdsu.FormatString.format("'%s: 0x%08x'", "address", 8592837)
 *                                            gives 'address: 0831dc5'
 * etc.
 * </pre>
 * The floating point to ASCII conversion is <b>very</b> incomplete.<p>
 *
 * Since all the <i>format</i> member functions are static, you will
 * never have to create a FormatString object.
 *
 * @author Andrew Scherpbier (<a href=mailto:andrew@sdsu.edu>andrew@sdsu.edu</a>)
 */
public class FormatString
{
    static char	outL[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8',
			  '9', 'a', 'b', 'c', 'd', 'e', 'f'};
    static char	outU[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8',
			  '9', 'A', 'B', 'C', 'D', 'E', 'F'};
	
    /** Don't let anyone instantiate this class */
    private FormatString()
    {
    }

    /** No docs for this one... */
    private static boolean intFormat(StringBuffer out, int width,
				       boolean left, boolean zeroes,
				       int base, long n)
    {
	char		digits[] = outL;
	boolean		negative = false;
	
	switch (base)
	{
	    case 'd':
	    case 'i':
		base = 10;
		break;
		
	    case 'o':
		base = 8;
		break;
		
	    case 'x':
		base = 16;
		break;
		
	    case 'X':
		base = 16;
		digits = outU;
		break;

	    default:
		return false;		// Unrecognized format character
	}

	char	output[] = new char[20];
	int	index = 0;
	if (n < 0)
	{
	    negative = true;
	    n = -n;
	    width--;
	}
	
	while (n > 0)
	{
	    long c = n % base;
	    n = n / base;
	    output[index++] = digits[(int) c];
	}
	if (index == 0)
	{
	    output[index++] = digits[0];
	}
	
	if (index > width)
	{
	    if (negative)
		out.append('-');
	    for (int i = index - 1; i >= 0; i--)
	    {
		out.append(output[i]);
	    }
	}
	else
	{
	    if (left)
	    {
		if (negative)
		    out.append('-');
		for (int i = index - 1; i >= 0; i--)
		{
		    out.append(output[i]);
		}
		addChars(out, width - index, ' ');
	    }
	    else
	    {
		if (zeroes)
		{
		    if (negative)
			out.append('-');
		    addChars(out, width - index, '0');
		}
		else
		{
		    addChars(out, width - index, ' ');
		    if (negative)
			out.append('-');
		}
		for (int i = index - 1; i >= 0; i--)
		{
		    out.append(output[i]);
		}
	    }
	}
	return true;
    }
    
    /**
     * Produce a formatted integer depending on the format pattern.
     *
     * The formatting rules are identical to those of the sprintf() C library
     * function.  The only restriction is that only one '%' escape can be used
     * and the command has to be 'd', 'o', 'x', or 'X'.
     *
     * @param fmt	the format string
     * @param n		the integer number to be formatted
     * @return		a new String with the formatted text.
     */
    public static String format(String fmt, long n)
    {
	int		position = 0;
	StringBuffer	output = new StringBuffer();
	char		character;
	int		width;
	boolean		left = false;
	boolean		leadingZeroes = false;

	while (position < fmt.length())
	{
	    character = fmt.charAt(position++);
	    if (character == '%')
	    {
		character = fmt.charAt(position++);
		if (character == '-')
		{
		    left = true;
		    character = fmt.charAt(position++);
		}
		if (character == '0')
		{
		    leadingZeroes = true;
		    character = fmt.charAt(position++);
		}
		width = 0;
		while (character >= '0' && character <= '9')
		{
		    width = width * 10 + (character - '0');
		    character = fmt.charAt(position++);
		}
		if (!intFormat(output, width, left, leadingZeroes, character, n))
		{
		    output.append("**FORMAT ERROR**");
		    continue;
		}
	    }
	    else
	    {
		output.append(character);
	    }
	}
	return output.toString();
    }

    /**
     * Produce a formatted string depending on the format pattern.
     *
     * The formatting rules are identical to those of the sprintf() C library
     * function.  The only restriction is that only one '%' escape can be used
     * and the command has to be 's'.
     *
     * @param fmt	the format string
     * @param s		the string to be formatted
     * @return		a new String with the formatted text.
     */
    public static String format(String fmt, String s)
    {
	int		position = 0;
	StringBuffer	output = new StringBuffer();
	char		character;
	int		width;
	boolean		left = false;

	while (position < fmt.length())
	{
	    character = fmt.charAt(position++);
	    if (character == '%')
	    {
		character = fmt.charAt(position++);
		if (character == '-')
		{
		    left = true;
		    character = fmt.charAt(position++);
		}
		width = 0;
		while (character >= '0' && character <= '9')
		{
		    width = width * 10 + (character - '0');
		    character = fmt.charAt(position++);
		}
		if (character != 's')
		{
		    output.append("**FORMAT ERROR**");
		    continue;
		}

		if (s.length() > width)
		{
		    output.append(s);
		}
		else
		{
		    if (left)
		    {
			output.append(s);
			addChars(output, width - s.length(), ' ');
		    }
		    else
		    {
			addChars(output, width - s.length(), ' ');
			output.append(s);
		    }
		}
	    }
	    else
	    {
		output.append(character);
	    }
	}
	
	return output.toString();
    }

    /**
     * Produce a formatted character depending on the format pattern.
     *
     * The formatting rules are identical to those of the sprintf() C library
     * function.  The only restriction is that only one '%' escape can be used
     * and the command has to be 'c'.
     *
     * @param fmt	the format string
     * @param c		the character to be formatted
     * @return		a new String with the formatted text.
     */
    public static String format(String fmt, char c)
    {
	int		position = 0;
	StringBuffer	output = new StringBuffer();
	char		character;
	int		width;
	boolean		left = false;

	while (position < fmt.length())
	{
	    character = fmt.charAt(position++);
	    if (character == '%')
	    {
		character = fmt.charAt(position++);
		if (character == '-')
		{
		    left = true;
		    character = fmt.charAt(position++);
		}
		width = 0;
		while (character >= '0' && character <= '9')
		{
		    width = width * 10 + (character - '0');
		    character = fmt.charAt(position++);
		}
		if (character != 'c')
		{
		    output.append("**FORMAT ERROR**");
		    continue;
		}

		if (left)
		{
		    output.append(c);
		    addChars(output, width - 1, ' ');
		}
		else
		{
		    addChars(output, width - 1, ' ');
		    output.append(c);
		}
	    }
	    else
	    {
		output.append(character);
	    }
	}
	
	return output.toString();
    }
    
    /**
     * Produce a formatted floating point number depending on the format pattern.
     *
     * The formatting rules are identical to those of the sprintf() C library
     * function.  The only restriction is that only one '%' escape can be used
     * and the command has to be 'f'.
     *
     * @param fmt	the format string
     * @param d		the floating point number to be formatted
     * @return		a new String with the formatted text.
     */
    public static String format(String fmt, double d)
    {
	int		position = 0;
	StringBuffer	output = new StringBuffer();
	char		character;
	int		width = 0;
	boolean		left = false;
	boolean		leadingZeroes = false;

	while (position < fmt.length())
	{
	    character = fmt.charAt(position++);
	    if (character == '%')
	    {
		character = fmt.charAt(position++);
		if (character == '-')
		{
		    left = true;
		    character = fmt.charAt(position++);
		}
		while (character >= '0' && character <= '9')
		{
		    width = width * 10 + (character - '0');
		    character = fmt.charAt(position++);
		}
		if (character != 'f')
		{
		    output.append("**FORMAT ERROR**");
		    continue;
		}

		String	temp = doubleFormat(d, 0, width);
		output.append(temp);
	    }
	    else
	    {
		output.append(character);
	    }
	}
	return output.toString();
    }

    private static String doubleFormat(double d, int width, int afterPeriod)
    {
	StringBuffer	output = new StringBuffer();
	int		exponent;
	double		temp;
	int		digit;
	int		zeroesNeeded = 0;

	exponent = (int) (Math.floor(Math.log(d) / Math.log(10)));
	d += 0.5 * Math.pow(10, -afterPeriod);
	
	temp = d / Math.pow(10, exponent);

	output.append((char)(Math.floor(temp) + '0'));
	output.append('.');
	for (int i = 0; i < afterPeriod; i++)
	{
	    temp *= 10;
	    digit = ((int) temp) % 10;
	    if (digit == 0)
	    {
		zeroesNeeded++;
	    }
	    else
	    {
		if (zeroesNeeded > 0)
		{
		    addChars(output, zeroesNeeded, '0');
		    zeroesNeeded = 0;
		}
		output.append((char)(digit + '0'));
	    }
	    
	}
	output.append('e');
	output.append(exponent);
	return output.toString();
    }
    
    /**
     * Produce a string depending on the format pattern.
     * This version will format two integers.
     *
     * The formatting rules are identical to those of the sprintf() C library
     * function.  The only restriction is that only two '%' escapes can be used
     * and the commands have to be 'd'.
     *
     * @param fmt	the format string
     * @param n1	the first integer to be formatted
     * @param n2	the second integer to be formatted
     * @return		a new String with the formatted text.
     */
    public static String format(String fmt, long n1, long n2)
    {
	StringBuffer	output = new StringBuffer();
	int		first = 0;
	int		last;

	last = fmt.indexOf('%');
	if (last < 0)
	    return fmt;

	last = fmt.indexOf('%', last + 1);
	output.append(format(fmt.substring(first, last), n1));
	first = last;

	output.append(format(fmt.substring(first), n2));

	return output.toString();
    }

    /**
     * Produce a string depending on the format pattern.
     * This version will format a string and an integer.
     *
     * The formatting rules are identical to those of the sprintf() C library
     * function.  The only restriction is that only two '%' escapes can be used
     * and the commands have to be 's' and 'd' (in that order).
     *
     * @param fmt	the format string
     * @param s1	the string to be formatted
     * @param n2	the integer to be formatted
     * @return		a new String with the formatted text.
     */
    public static String format(String fmt, String s1, long n2)
    {
	StringBuffer	output = new StringBuffer();
	int		first = 0;
	int		last;

	last = fmt.indexOf('%');
	if (last < 0)
	    return fmt;

	last = fmt.indexOf('%', last + 1);
	output.append(format(fmt.substring(first, last), s1));
	first = last;

	output.append(format(fmt.substring(first), n2));

	return output.toString();
    }

    /**
     * Produce a string depending on the format pattern.
     * This version will format an integer and a string.
     *
     * The formatting rules are identical to those of the sprintf() C library
     * function.  The only restriction is that only two '%' escapes can be used
     * and the commands have to be 'd' and 's' (in that order).
     *
     * @param fmt	the format string
     * @param n1	the integer to be formatted
     * @param s2	the string to be formatted
     * @return		a new String with the formatted text.
     */
    public static String format(String fmt, long n1, String s2)
    {
	StringBuffer	output = new StringBuffer();
	int		first = 0;
	int		last;

	last = fmt.indexOf('%');
	if (last < 0)
	    return fmt;

	last = fmt.indexOf('%', last + 1);
	output.append(format(fmt.substring(first, last), n1));
	first = last;

	output.append(format(fmt.substring(first), s2));

	return output.toString();
    }

    /**
     * Produce a string depending on the format pattern.
     * This version will format two strings.
     *
     * The formatting rules are identical to those of the sprintf() C library
     * function.  The only restriction is that only two '%' escapes can be used
     * and the commands have to be '2'.
     *
     * @param fmt	the format string
     * @param s1	the first string to be formatted
     * @param s2	the second string to be formatted
     * @return		a new String with the formatted text.
     */
    public static String format(String fmt, String s1, String s2)
    {
	StringBuffer	output = new StringBuffer();
	int		first = 0;
	int		last;

	last = fmt.indexOf('%');
	if (last < 0)
	    return fmt;

	last = fmt.indexOf('%', last + 1);
	output.append(format(fmt.substring(first, last), s1));
	first = last;

	output.append(format(fmt.substring(first), s2));

	return output.toString();
    }

    /**
     * Produce a string depending on the format pattern.
     * This version will format three integers.
     *
     * The formatting rules are identical to those of the sprintf() C library
     * function.  The only restriction is that only three '%' escapes can be used
     * and the commands have to be 'd'.
     *
     * @param fmt	the format string
     * @param n1	the first integer to be formatted
     * @param n2	the second integer to be formatted
     * @param n3	the third integer to be formatted
     * @return		a new String with the formatted text.
     */
    public static String format(String fmt, long n1, long n2, long n3)
    {
	StringBuffer	output = new StringBuffer();
	int		first = 0;
	int		last;

	last = fmt.indexOf('%');
	if (last < 0)
	    return fmt;

	last = fmt.indexOf('%', last + 1);
	output.append(format(fmt.substring(first, last), n1));
	first = last;

	last = fmt.indexOf('%', last + 1);
	output.append(format(fmt.substring(first, last), n2));
	first = last;

	output.append(format(fmt.substring(first), n3));

	return output.toString();
    }

    
    private static void addChars(StringBuffer s, int n, char c)
    {
	for (int i = 0; i < n; i++)
	    s.append(c);
    }
    
}


