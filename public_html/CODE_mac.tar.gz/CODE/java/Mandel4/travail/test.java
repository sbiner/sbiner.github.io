public class test {
    //main
    public static void main(String[] args) {
	classA ca = new classA() ;
	classB cb = new classB(ca) ;
	monThread mt ;

	// affichage
	ca.montreVal() ;
	cb.montreVal() ;

	ca.valA=3 ;
	cb.ca.montreVal() ;
	
	// thread
	mt=new monThread(cb) ;

    }
}

class classA {
    int valA=1 ;
    // constructeur
    classA() {
	System.out.println("constructeur classA") ;
    }
    // methode montre val
    void montreVal() {
	System.out.println("valA="+valA) ;
    }
}

class classB {
    classA ca ;
    int valB=2 ;
    // constructeur
    classB(classA caPasse) {
	this.ca=caPasse ;
	System.out.println("constructeur classB") ;
    }
    // methode montre val
    void montreVal() {
	System.out.println("valB="+valB) ;
    }
}

// classe MandelThread1 
class monThread extends Thread{
    
    classA ca ;
    classB cb ;
       
    // constructeur
    monThread(classB cbPasse) { 
	System.out.println("nouveau Thread") ;

	this.cb=cbPasse ;
	this.ca=this.cb.ca ;
	start() ;
    }
    
    // methode run
    public void run() {
	System.out.println("debut Thread") ;
	cb.montreVal() ;
	cb.ca.montreVal() ;
	System.out.println("fin Thread") ;
	return ;
    } // fin methode run
    
}//fin de MandelThread1 

