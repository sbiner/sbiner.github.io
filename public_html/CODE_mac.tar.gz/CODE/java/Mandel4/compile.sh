#! /bin/sh

set -aex

javac -d class -classpath class -sourcepath src src/*.java

cd class
jar cf ../build/Mandel4.jar *.class
cd ..
