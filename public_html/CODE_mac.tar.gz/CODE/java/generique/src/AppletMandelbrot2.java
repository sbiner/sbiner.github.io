/*
<applet code="AppletMandelbrot2.class" width=800 height=500>
</applet>
 */

import javax.swing.* ;
import javax.swing.event.* ;
import javax.swing.text.* ;
import java.awt.* ;
import java.awt.image.* ;
import java.io.* ;
import javax.imageio.* ;
import java.awt.event.* ;



public class AppletMandelbrot2 extends JApplet{

    Container cp ;
    MandelThread1 mt ;
    public PanelGraph2 pdessin ;
    
    //
    //init
    //

    public void init() {

	// on creer le panneau avec le graph
	pdessin = new PanelGraph2(500,500) ;
	//pdessin.genereImage() ;

	// on creer le panneau de controle
	PanneauControle pcontrole = new PanneauControle(pdessin) ;
	pcontrole.setPreferredSize(new Dimension(300,500)) ;

	// on ajoute les panneaux a l'Applet
	cp=getContentPane() ;
	cp.setLayout(new BoxLayout(cp,BoxLayout.X_AXIS)) ;
	cp.add(pcontrole) ;
	cp.add(pdessin) ;
	
	

    } // fin init


} // fin  AppletMandebrot1

//////////////////////////////////////////////////
// panneau de controle
//////////////////////////////////////////////////
class PanneauControle extends JPanel {

    // variables
    MandelThread1 mt = null ;
    PanelGraph2 pg2 ;
    
    JTextField jtfxmax, jtfxmin, jtfymin, jtfymax ;
    JTextField jtfreMu, jtfimMu, jtfnbIt, jtfrayonCritique ;

    // constructeur
    PanneauControle(PanelGraph2 pg2Passe) {
	
	// on passe pg2Passe 
	this.pg2=pg2Passe ;
	
	// initialisation des textfields

	jtfxmin=new JTextField(doubleAString(pg2.xmin)) ;
	jtfxmin.getDocument().putProperty("nom","xmin") ;
	jtfxmin.getDocument().addDocumentListener(new DocL1()) ;

	jtfxmax=new JTextField(doubleAString(pg2.xmax)) ;
	jtfxmax.getDocument().putProperty("nom","xmax") ;
	jtfxmax.getDocument().addDocumentListener(new DocL1()) ;

	jtfymin=new JTextField(doubleAString(pg2.ymin)) ;
	jtfymin.getDocument().putProperty("nom","ymin") ;
	jtfymin.getDocument().addDocumentListener(new DocL1()) ;

	jtfymax=new JTextField(doubleAString(pg2.ymax)) ;
	jtfymax.getDocument().putProperty("nom","ymax") ;
	jtfymax.getDocument().addDocumentListener(new DocL1()) ;

	jtfreMu=new JTextField(doubleAString(pg2.reMu))  ;
	jtfreMu.getDocument().putProperty("nom","reMu") ;
	jtfreMu.getDocument().addDocumentListener(new DocL1()) ;

	jtfimMu=new JTextField(doubleAString(pg2.imMu))  ;
	jtfimMu.getDocument().putProperty("nom","imMu") ;
	jtfimMu.getDocument().addDocumentListener(new DocL1()) ;

	jtfnbIt=new JTextField(intAString(pg2.nbIterationsMax)) ;
	jtfnbIt.getDocument().putProperty("nom","nbIt") ;
	jtfnbIt.getDocument().addDocumentListener(new DocL1()) ;

	jtfrayonCritique=new JTextField(doubleAString(pg2.rayonCritique)) ;
	jtfrayonCritique.getDocument().putProperty("nom","rayonCritique") ;
	jtfrayonCritique.getDocument().addDocumentListener(new DocL1()) ;

	// panneau avec entrees
	JPanel p1 = new JPanel() ;
	p1.setLayout(new GridLayout(0,2)) ;
	// addition des boutons et textfields
	// xmin xmax
	p1.add(new JLabel("xmin",JLabel.CENTER)) ;
	p1.add(jtfxmin) ;
	p1.add(new JLabel("xmax",JLabel.CENTER));
	p1.add(jtfxmax) ;
	// ymin, ymax
	p1.add(new JLabel("ymin",JLabel.CENTER)) ;
	p1.add(jtfymin) ;
	p1.add(new JLabel("ymax",JLabel.CENTER));
	p1.add(jtfymax) ;
	// mu
	p1.add(new JLabel("Re(mu)",JLabel.CENTER)) ;
	p1.add(jtfreMu) ;
	p1.add(new JLabel("Im(mu)",JLabel.CENTER)) ;
	p1.add(jtfimMu) ;
	// nb iteration
	p1.add(new JLabel("Nb Iterations",JLabel.CENTER)) ;
	p1.add(jtfnbIt) ;
	// rayon
	p1.add(new JLabel("rayon",JLabel.CENTER)) ;
	p1.add(jtfrayonCritique) ;
	
	// boutons 
	JButton bRedessine = new JButton("refaire graph") ;
	bRedessine.addActionListener(new OnOffL()) ;
	JButton bStop = new JButton("arreter calculs") ;
	
	setLayout(new BoxLayout(this,BoxLayout.Y_AXIS)) ;
	p1.setPreferredSize(new Dimension(300,300)) ;
	add(p1) ;
	add(bRedessine) ;
	add(bStop) ;
	
    }// fin constructeur

    //
    // methodes 
    //

    // methode pour mettre les textField a jour avec les attributs de
    // pg2
    void majJtf() {
	jtfxmax.setText(doubleAString(pg2.xmax)) ;
	jtfxmin.setText(doubleAString(pg2.xmin)) ;
	jtfymax.setText(doubleAString(pg2.ymax)) ;
	jtfymin.setText(doubleAString(pg2.ymin)) ;
	jtfreMu.setText(doubleAString(pg2.reMu)) ;
	jtfimMu.setText(doubleAString(pg2.imMu)) ;
	jtfnbIt.setText(intAString(pg2.nbIterationsMax)) ;
	jtfrayonCritique.setText(doubleAString(pg2.rayonCritique)) ;
    } // fin majJtf

    // methode pour passer un double a un textfield
    String doubleAString (double x) {
	StringBuffer sb = new StringBuffer() ;
	sb.append(x) ;
	return sb.toString() ;
    }
    // methode pour passer un int a un textfield
    String intAString (int x) {
	StringBuffer sb = new StringBuffer() ;
	sb.append(x) ;
	return sb.toString() ;
    }

    //
    // Listener
    //
    // Bouton OnOff
    class OnOffL implements ActionListener {
	public void actionPerformed(ActionEvent e) {
	    if (mt == null) {
		majJtf() ;
		pg2.montreCentre=Boolean.FALSE ;
		mt = new MandelThread1(pg2) ;
		mt = null ;
		
	    }
	}
    } // fin OnOffL

    // Textfield
    class DocL1 implements DocumentListener {
	// on implemente l'interface
	public void insertUpdate(DocumentEvent e) {
	    modifValeur(e) ;
	}
	public void removeUpdate(DocumentEvent e) {
	    modifValeur(e) ;
	}
	public void changedUpdate(DocumentEvent e) {
	}
	// on genere la methode modif_valeur
	private void modifValeur (DocumentEvent e) {
	    // cette methode modifie les parametre de pg2 selon
	    // ce qui est entre dans les TextField
	    Document val = e.getDocument() ;
	    if (val.getProperty("nom").equals("xmax")) {
		pg2.xmax=stradbl(jtfxmax.getText(),pg2.xmax) ;
	    }
	    else if (val.getProperty("nom").equals("xmin")) {
		pg2.xmin=stradbl(jtfxmin.getText(),pg2.xmin) ;
	    }
	    else if (val.getProperty("nom").equals("ymax")) {
		pg2.ymax=stradbl(jtfymax.getText(),pg2.ymax) ;
	    }
	    else if (val.getProperty("nom").equals("ymin")) {
		pg2.ymin=stradbl(jtfymin.getText(),pg2.ymin) ;
	    }
	    else if (val.getProperty("nom").equals("reMu")) {
		pg2.reMu=stradbl(jtfreMu.getText(),pg2.reMu) ;
	    }
	    else if (val.getProperty("nom").equals("imMu")) {
		pg2.imMu=stradbl(jtfimMu.getText(),pg2.imMu) ;
	    }
	    else if (val.getProperty("nom").equals("nbIt")) {
		pg2.nbIterationsMax=straint(jtfnbIt.getText(),pg2.nbIterationsMax) ;
	    }
	    else if (val.getProperty("nom").equals("rayonCritique")) {
		pg2.rayonCritique=stradbl(jtfrayonCritique.getText(),pg2.rayonCritique) ;
	    }
	} // fin modifValeur
	//
	private double stradbl(String s, double defaut) {
	    // fonction qui tente de tirer un double de s sinon elle
	    // passe la valeur par defaut
	    double d ;
	    try{
		d=Double.parseDouble(s) ;
	    } catch (Exception e) { d=defaut ; }
	    return d ;
	} //fin stradbl
	private int straint(String s, int defaut) {
	    // fonction qui tente de tirer un int de s sinon elle
	    // passe la valeur par defaut
	    int d ;
	    try{
		d=Integer.parseInt(s) ;
	    } catch (Exception e) { d=defaut ; }
	    return d ;
	} //fin straint
    } // fin DocL1

} // fin panneauControle

//////////////////////////////////////////////////
// panneau de dessin
//////////////////////////////////////////////////
// debut PanelGraph2
class PanelGraph2 extends JPanel{
	 
    // grandeur image (en pixel)
    Dimension dimImage ;

    // variables servant a generer le graphique
    double xmin,xmax,ymin,ymax,rayonCritique ;
    double reMu,imMu ;
    int nbIterationsMax ;

    // variable concernant le centre
    Boolean montreCentre ;
    int iCentre, jCentre ;

    // variable utiliser pour le tampon de l'image
    BufferedImage bi ;
    
    // constructeur 
    PanelGraph2(int ni, int nj) { 
	this.setPreferredSize(new Dimension(ni,nj)) ;
	dimImage = new Dimension(this.getPreferredSize()) ;
	System.out.println("/nnouveau PanelGraph") ;
	System.out.println("hauteur="+dimImage.getHeight()) ;	
	System.out.println("largeur="+dimImage.getWidth()) ;		
	//	bi = new BufferedImage((double)dimImage.getWidth(),
	//		       (double)dimImage.getHeight(),
	//		       BufferedImage.TYPE_INT_RGB) ;
	bi=new BufferedImage(500,500,BufferedImage.TYPE_INT_RGB) ;

	// initialisation des variables
	xmin=-2.0 ; xmax=2.0 ;
	ymin=-1.25 ; ymax=1.25 ;
	rayonCritique=5.0 ;
	nbIterationsMax=50 ;
	reMu=0.9 ; imMu=0.0 ;

	montreCentre=Boolean.FALSE ;

	// implementation du listener de souris

	this.addMouseListener(new ml()) ;

    } // fin constructeur

    //
    // METHODES
    //

    // methode qui genere l'image tampon (BufferedImage)

    public void genereImage() {
	
	// variables
	Graphics2D big ;
	int di,dj,i1,j1,i2,j2 ;
	float indice_couleur ;
	Color couleur ;
	Rainbow paletteArcEnCiel = new Rainbow() ;
	int indice_palette ;
	double valmin, valmax, valeur ;

	// on creer le graphique pour dessiner
	big=bi.createGraphics() ;

	// initialisation de certaines variables
	di=1 ; dj=1 ;
	valmin=0.0 ; valmax=(double)nbIterationsMax ;

	System.out.println("debut des calculs") ;
	// boucle sur les points
	i1=0  ;
	for (int i=0;i<dimImage.getWidth()-1;i++){
	    if (i % 10 == 0) { System.out.println("colonne i="+i) ; }
	    j1=0 ;
	    for (int j=0;j<dimImage.getHeight();j++){
		
		valeur=calculeValeur(i,j) ;
		indice_couleur=(float)((valeur-valmin)/(valmax-valmin)) ;
		indice_palette=(int)(indice_couleur*255) ;
		couleur=paletteArcEnCiel.rgb[255-indice_palette] ;
		big.setColor(couleur) ;
		
		i2=i1+di ; j2=j1+dj ;
		
		big.fillRect(i1,j1,i2,j2) ;

		j1+=dj ;
	    } // fin boucle j
	    i1+=di ;
	} // fin boucle i
	System.out.println("fin des calculs") ;

	big.dispose() ;
	repaint() ;

    } // fin genereImage

   // methode qui repaint le panneau //
    
    public void paintComponent (Graphics g){
	super.paintComponent(g) ;
	update(g) ;
    }// fin paintComponent

    public void update (Graphics g){

	// variables
	Graphics2D g2 ;

	super.paintComponent(g) ;
	g2=(Graphics2D)g ;
	
	g2.drawImage(bi,null,0,0) ;

	// on affiche le centre si demande 
	if (montreCentre == Boolean.TRUE ) {
	    int nPixel=10 ;
	    g2.setColor(Color.WHITE) ;
	    g2.fillOval(iCentre-nPixel/2,jCentre-nPixel/2,
			nPixel,nPixel) ;
	}


	System.out.println("passe dans update") ;
    } // fin update
    
    // methode calculeValeur
    public double calculeValeur(int i, int j) {
	
	// variables internes
	double x,y,dx,dy ;
	Complex z,mu ;
	double rayon ;
	int it=0;

	// initialisation
	dx=(xmax-xmin)/dimImage.getWidth() ;
	dy=(ymax-ymin)/dimImage.getHeight() ;
	
	// calcule des coord du centre du point
	x=xmin+(i+0.5)*dx ;
	//y=ymin+(j+0.5)*dy ;
	// inversion de l'axe des x
	y=ymax-(j+0.5)*dy ;

	z=new Complex(x,y) ;
	mu=new Complex(reMu,imMu) ;
	rayon=rayonCritique ;

	// debug
	/*
	if (i == 54 && j == 249) { 
	    System.out.println("x="+x) ;
	    System.out.println("y="+y) ;
	    System.out.println("dx="+dx) ;
	    System.out.println("dy="+dy) ;
	    System.out.println("rayonCritique="+rayonCritique) ;
	    System.out.println("nbIterationsMax="+nbIterationsMax) ;
	    System.out.println("rayon="+rayon) ;
	}
	*/
	
	while (it < nbIterationsMax && rayon <= rayonCritique) {
	    z=z.times(z) ;
	    z=z.subtract(z,mu) ;
	    rayon=z.norm() ;
	    it++ ;
	}
	return (double)it ;
		
    } // fin calculeValeur


    // 
    // LISTENER
    //
    class ml implements MouseListener {
	public void mouseClicked(MouseEvent e) {
	changeCentre(e) ;
	}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
	
	}
	public void mouseReleased(MouseEvent e) {}

	// methode qui change le centre de la figure
	void changeCentre(MouseEvent e) {
    	    double x0,y0 ;
	    double pente, longueur ;
	    iCentre=e.getX() ;
	    jCentre=e.getY() ;
	    // passage de pixel (i,j) en coord x,y
	    longueur=xmax-xmin ;
	    pente=longueur/dimImage.getWidth() ;
	    // x
	    x0=xmin+iCentre*pente ;
	    xmin=x0-longueur/2 ;
	    xmax=x0+longueur/2 ;
	    System.out.println("x0="+x0) ;
	    System.out.println("xmin="+xmin) ;	    
	    System.out.println("xmax="+xmax) ;
	    System.out.println("long="+longueur) ;

	    // y
	    longueur=ymax-ymin ;
	    pente=longueur/dimImage.getHeight() ;
	    y0=ymax-jCentre*pente ;
	    ymin=y0-longueur/2 ;
	    ymax=y0+longueur/2 ;
	    // on indique qu'on doit montrer le centre
	    montreCentre=Boolean.TRUE ;
	    repaint() ;

	} // fin changeCentre

    } // fin ml


} // fin panelGraph2

// classe MandelThread1 
class MandelThread1 extends Thread{

    PanelGraph2 pg2;

    // constructeur
    MandelThread1(PanelGraph2 pg2Passe) { 
	System.out.println("nouveau MandelThread1") ;
	// on initialise pg2 avec pg2Passe

	this.pg2=pg2Passe ;
	start() ;
    }

    // methode run
    public void run() {
	pg2.genereImage() ;
	return ;
    } // fin methode run

}//fin de MandelThread1 

