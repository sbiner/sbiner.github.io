import javax.swing.* ;

public class HelloWorldSwing {
	 private static void createAndShowGUI() {
		  // assurer des belles deco
		  JFrame.setDefaultLookAndFeelDecorated(true) ;
		  
		  // creer la fenetre et set-up
		  JFrame frame = new JFrame("Salut tout le monde") ;
		  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
		  
		  // ajouter le Label
		  JLabel label = new JLabel("salut tout le monde") ;
		  frame.getContentPane().add(label) ;
		  
		  // afficher la fenetre
		  frame.pack();
		  frame.setVisible(true) ;
	 }
	 
	 public static void main(String[] args){
		  javax.swing.SwingUtilities.invokeLater(new Runnable() {
					 public void run() {
						  createAndShowGUI();
					 }
				});
	 }  

}
