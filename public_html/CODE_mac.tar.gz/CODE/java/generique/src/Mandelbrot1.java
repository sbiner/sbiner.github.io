/*
programme pour tracer un graphique de mandelbrot
*/


import javax.swing.* ;
import java.awt.* ;

public class Mandelbrot1 {

    // main
    public static void main(String[] args) {
	// creation du frame
	JFrame frame = new JFrame("Mandelbrot1") ;
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// creation du panel de base
	JPanel panelBase = new JPanel() ;
	frame.setContentPane(panelBase) ;
	
	// creation et addition des composantes
	
	JLabel label1 = new JLabel("bonjour") ;
	PanelGraph panel1 = new PanelGraph();
	panel1.setPreferredSize(new Dimension(500,500)) ;
	//panel1.calculePoints() ;
	panel1.calculeMandelbrot1() ;

	panelBase.add(label1);
	panelBase.add(panel1);
	
	// on rend le frame visible
	
	frame.pack() ;
	frame.setVisible(true) ;
	
    } // fin main

} // fin Mandelbrot1

// debut PanelGraph
class PanelGraph extends JPanel{
	 
    // def variables
    final int NiCalcul=10 ;
    final int NjCalcul=10 ;

    double [][] val = new double [NiCalcul][NjCalcul] ;
    double valmin, valmax ;
    
    // methode qui repaint le paneau //
    
    public void paintComponent (Graphics g){
	super.paintComponent(g) ;
	
	// variables
	int di,dj,i1,j1,i2,j2 ;
	float indice_couleur ;
	Color couleur ;
	Rainbow paletteArcEnCiel = new Rainbow() ;
	int indice_palette ;

	// partie qui fait le dessin
	Rectangle grandeur = this.getBounds();
	di=(int)grandeur.width/NiCalcul ;
	dj=(int)grandeur.height/NjCalcul ;
	//
	// boucle sur les points
	i1=0  ;
	for (int i=0;i<NiCalcul-1;i++){
	    j1=0 ;
	    for (int j=0;j<NjCalcul;j++){
		// 
		//indice_couleur=(float)((val[i][j]-valmin)/(valmax-valmin)) ;
		indice_couleur=(float)((val[i][j]-valmin)/(valmax-valmin)) ;
		couleur=new Color(Color.HSBtoRGB(indice_couleur,1,1));
		indice_palette=(int)(indice_couleur*255) ;
		couleur=paletteArcEnCiel.rgb[indice_palette] ;
		    
		g.setColor(couleur) ;
		
		i2=i1+di ; j2=j1+dj ;
		
		g.fillRect(i1,j1,i2,j2) ;
		//
 		//debug if (i <=2 && j <=2) System.out.println("pixel ("+i1+","+j1+"),("+i2+","+j2+")");
		j1+=dj ;
		
		
	    }
	    i1+=di ;
	}
	
	System.out.println("passe dans paint") ;
    } // fin paintComponent
    
    // methodes qui calcule les points //
    
    public void calculePoints() {
	
	// nb d'onde en x et y
	double kx=1.0,ky=1.0 ;
	// 
	kx=kx*2*Math.PI/NiCalcul ;
	ky=ky*2*Math.PI/NjCalcul ;
	
	// boucle sur i,j
	for (int j=0;j<NjCalcul;j++) {
	    for (int i=0;i<NiCalcul;i++){
		val[i][j]=Math.sin(i*kx)+Math.cos(j*ky) ;
	    }
	}
	valmin=-2 ;
	valmax=2;

	//		  return val ;
    } // fin calculePoints

    public void calculeMandelbrot1() {
	
	// variables
	double xmin,xmax,ymin,ymax,dx,dy,x,y ;
	xmin=-2.0 ; xmax=2.0 ;
	ymin=-1.25 ; ymax=1.25 ;
	
	dx=(xmax-xmin)/NiCalcul ;
	dy=(ymax-ymin)/NjCalcul ;

	Complex z,zmoins ;
	double dist,epsilon=2. ;
	int NbIterationsMax=50 ;
	int it=0 ;

	valmin=0 ;
	valmax=(double)NbIterationsMax ;

	// boucle sur tous les points
	for (int j=0;j<NjCalcul;j++){
	    for (int i=0;i<NiCalcul;i++){
		
		// calcule des coord du centre du point
		x=xmin+(i+0.5)*dx ;
		y=ymin+(j+0.5)*dy ;

		z=new Complex(x,y) ;
		dist=epsilon ;
		//debug System.out.println("iteration 0,z="+z.toString());
		it=0 ;

		while (it < NbIterationsMax && dist <= epsilon){
		    z=z.times(z) ;
		    z=z.subtract(z,0.75) ;
		    dist=z.norm() ;
		    it++ ;
		    //		    System.out.println("iteration "+it+",z="+z.toString());
		}
		val[i][j]=(double)it ;

		//debug System.out.println("point i,j="+i+" "+j);
		//debug System.out.println("x,y,val="+x+" "+y+" "+val[i][j]);
		
	    }

	}


    }


} // fin panelGraph

/*
public class Complex {

  public double x,y;

  public Complex() {
    x = 0.0;
    y = 0.0;
  }

  public Complex(double x) {
    this.x = x;
    this.y = 0.0;
  }

  public Complex(double x, double y) {
    this.x = x;
    this.y = y;
  }

  public Complex(Complex z) {
    this.x = z.x;
    this.y = z.y;
  }
  
  public String toString() {
    if (y>=0)
      return x+"+"+y+"i";
    else
      return x+"-"+(-y)+"i";
  }

  
  // find the inner product when the numbers are treated as vectors
  public double innerProduct (Complex w) {
    return x*w.x + y*w.y;
  }
  
  public static double innerProduct (Complex z, Complex w) {
    return z.x*w.x + z.y*w.y;
  }

  public double normSquared() {
    return x*x + y*y;
  }

  public double norm() {
    return Math.sqrt(x*x + y*y);
  }
  
  public Complex conjugate() {
    return new Complex (x, -y);
  }

  public Complex negation () {
    return new Complex (- x, y); 
  }
  public Complex minus (Complex w) {
    return new Complex (x - w.x, y - w.y); 
  }
  
  public Complex minus (double t) {
    return new Complex (x - t, y);
  }

  public static Complex subtract (Complex z, Complex w) {
    return new Complex (z.x - w.x, z.y - w.y);
   }

  public static Complex subtract (double t, Complex w) {
    return new Complex (t - w.x, -w.y);
   }
  
  public static Complex subtract (Complex z, double t) {
    return new Complex (z.x - t, z.y);
   }

  public Complex plus (Complex w) {
    return new Complex (x + w.x, y + w.y);
  }

  public Complex plus (double t) {
    return new Complex (x + t, y);
  }

  public static Complex add (Complex z, Complex w) {
    return new Complex (z.x + w.x, z.y + w.y);
   }

  public static Complex add (double t, Complex w) {
    return new Complex (t + w.x, w.y);
   }

  public static Complex add (Complex z, double t) {
    return new Complex (z.x + t, z.y);
   }

  public Complex times (Complex w) {
    return new Complex (x*w.x - y*w.y, y*w.x + x*w.y);
  }

  public Complex times (double t) {
    return new Complex (t*x, t*y);
  }

  public static Complex multiply (Complex z, Complex w) {
    return new Complex (z.x*w.x - z.y*w.y, z.y*w.x + z.x*w.y);
   }

  public static Complex multiply (double t, Complex w) {
    return new Complex (t*w.x, t*w.y);
   }

  public static Complex multiply (Complex z, double t) {
    return new Complex (t*z.x, t*z.y);
   }

  public Complex reciprocal() {
    double den = normSquared();
    return new Complex (x/den, -y/den);
   }
  public Complex over (Complex w) {
    double den = w.normSquared();
    return new Complex ((x*w.x + y*w.y)/den, (y*w.x - x*w.y)/den);
  }
  
  public Complex over (double t) {
    return new Complex (x/t, y/t); 
  }

  public static Complex divide (Complex z, Complex w) {
    double den = w.normSquared();
    return new Complex ((z.x*w.x + z.y*w.y)/den, (z.y*w.x - z.x*w.y)/den);
   }

  public static Complex divide (double t, Complex w) {
    double den = w.normSquared();
    return new Complex (t*w.x/den, -t*w.y/den);
  }
  
  public static Complex divide (Complex z, double t) {
    return new Complex (z.x/t, z.y/t);
  }
   
  public Complex sqrt () {
    double n = norm();
    double s = Math.sqrt((n + x)/2.0);
    double t = (y >= 0.0)?
      Math.sqrt((n - x)/2.0):
      -Math.sqrt((n - x)/2.0);
    return new Complex (s,t);
  }
} // Complex
*/
