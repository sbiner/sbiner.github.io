/*
<applet code="ColorGradient.class" codebase="../class" width=525 height=150>
<param name="startColor" value="#ff0000">
<param name="endColor" value="#0000ff">
</applet>
*/

import java.applet.* ;
import java.awt.* ;

/** Applet qui montre les couleurs en java **/
public class ColorGradient extends Applet {
	 Color startColor, endColor ;
	 Font bigFont ;

	 public void init() {
		  try {
				startColor=Color.decode(getParameter("startColor"));
				endColor=Color.decode(getParameter("endColor"));
		  }
		  catch (NumberFormatException e) {
				startColor=endColor=Color.white ;
		  }
		  bigFont=new Font("Helvetica",Font.BOLD,72) ;
	 }

	 // dessiner l'applet
	 public void paint (Graphics g){
		  fillGradient(this,g,startColor,endColor);
		  g.setFont(bigFont);
		  g.setColor(new Color(100,100,200));
		  g.drawString("TOTO",100,100);
	 }


	 // remplir le gradient de couleur

	 public void fillGradient(Component c, Graphics g, Color start, Color end){

		  Color coul ;
		  float yy ;
		  Rectangle bounds = this.getBounds() ;
		  //
		  float r1 = start.getRed()/255.0f ;
		  float g1 = start.getGreen()/255.0f ;
		  float b1 = start.getBlue()/255.0f ;
		  float r2 = end.getRed()/255.0f ;
		  float g2 = end.getGreen()/255.0f ;
		  float b2 = end.getBlue()/255.0f ;
		  //
		  float dr=(r2-r1)/bounds.height ;
		  float dg=(g2-g1)/bounds.height ;
		  float db=(b2-b1)/bounds.height ;
		  //
		  for (int y = 0;y<bounds.height;y++) {
				//				g.setColor(new Color(r1,g1,b1)) ;
				//yy=y/(float)bounds.height ;
				//yy=(float)y/(float)bounds.height ;
				yy=y.floatValue() ;
				System.out.println("y="+y) ;
				System.out.println("bounds.height="+bounds.height) ;
				System.out.println("yy="+yy) ;
				coul = new Color(Color.HSBtoRGB(yy,1,1));
				g.setColor(coul) ;
				g.drawLine(0,y,bounds.width-1,y) ;
				r1+=dr ; g1+=dg ; b1+=db ;
		  }
		  
	 }


}
