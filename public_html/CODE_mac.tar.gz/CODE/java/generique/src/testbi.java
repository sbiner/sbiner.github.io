/*
programme pour tracer un graphique de mandelbrot
*/


import javax.swing.* ;
import java.awt.* ;
import java.awt.image.* ;
import java.io.* ;
import javax.imageio.* ;

public class testbi {

    // main
    public static void main(String[] args) {

	// variables
	BufferedImage bi = new BufferedImage(500,500,BufferedImage.TYPE_INT_RGB) ;
	Graphics2D big ;
	Color couleur = new Color(255,0,0) ;
	
	big=bi.createGraphics() ;
	big.setColor(couleur) ;
	big.fillRect(0,0,500,500) ;
	big.setColor(new Color(0,255,0)) ;
	big.fillRect(100,100,300,300) ;

	File file = new File("toto.jpg") ;
	try {
	    ImageIO.write(bi,"jpg",file) ;
	} catch(IOException e) {
	    System.out.println("coucou") ;
	} 
	big.dispose() ;

    }
}

