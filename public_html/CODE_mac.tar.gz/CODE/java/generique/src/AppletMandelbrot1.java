/*
<applet code="AppletMandelbrot1.class" width=800 height=500>
</applet>
 */

import javax.swing.* ;
import java.awt.* ;
import java.awt.image.* ;
import java.io.* ;
import javax.imageio.* ;



public class AppletMandelbrot1 extends JApplet{

    Container cp ;
    
    public void init() {

	// changer lookandfeel
	/*
	try{ 
	    UIManager.setLookAndFeel()  ;
	} 
	catch(Exception e) { System.out.println("erreur laf") ;
	} 
	*/

	// on creer le panneau de controle
	PanneauControle pcontrole = new PanneauControle() ;
	pcontrole.setPreferredSize(new Dimension(300,500)) ;

	// on creer le panneau de dessin
	PanelGraph2 pdessin = new PanelGraph2(500,500) ;
	//pdessin.setPreferredSize(new Dimension(500,500)) ;
	//pdessin.calculeMandelbrot1() ;
	System.out.println("passe ici") ;
	pdessin.genereImage() ;

	// on ajoute les panneaux
	cp=getContentPane() ;
	cp.setLayout(new BoxLayout(cp,BoxLayout.X_AXIS)) ;
	cp.add(pcontrole) ;
	cp.add(pdessin) ;

    } // fin init

    class PanneauControle extends JPanel {

	// constructeur
	PanneauControle() {

	    // panneau avec entrees
	    JPanel p1 = new JPanel() ;
	    p1.setLayout(new GridLayout(0,2)) ;
	    // addition des boutons et textfields
	    // xmin xmax
	    p1.add(new JLabel("xmin",JLabel.CENTER)) ;
	    p1.add(new JTextField("xmin")) ;
	    p1.add(new JLabel("xmax",JLabel.CENTER));
	    p1.add(new JTextField("xmax")) ;
	    // ymin, ymax
	    p1.add(new JLabel("ymin",JLabel.CENTER)) ;
	    p1.add(new JTextField("ymin")) ;
	    p1.add(new JLabel("ymax",JLabel.CENTER));
	    p1.add(new JTextField("ymax")) ;
	    // mu
	    p1.add(new JLabel("Re(mu)",JLabel.CENTER)) ;
	    p1.add(new JTextField("Re(mu)")) ;
	    p1.add(new JLabel("Im(mu)",JLabel.CENTER)) ;
	    p1.add(new JTextField("Im(mu)")) ;
	    // nb iteration
	    p1.add(new JLabel("Nb Iterations",JLabel.CENTER)) ;
	    p1.add(new JTextField("Nb Iterations")) ;
	    // rayon
	    p1.add(new JLabel("rayon",JLabel.CENTER)) ;
	    p1.add(new JTextField("rayon")) ;

	    // boutons 
	    JButton bRedessine = new JButton("refaire graph") ;
	    JButton bStop = new JButton("arreter calculs") ;
	    
	    setLayout(new BoxLayout(this,BoxLayout.Y_AXIS)) ;
	    p1.setPreferredSize(new Dimension(300,300)) ;
	    add(p1) ;
	    add(bRedessine) ;
	    add(bStop) ;
	    
	}// fin constructeur

    } // fin panneauControle

} // fin  AppletMandebrot1

// debut PanelGraph2
class PanelGraph2 extends JPanel{
	 
    // grandeur image (en pixel)
    Dimension dimImage ;

    // variables servant a generer le graphique
    double xmin,xmax,ymin,ymax,rayonCritique ;
    double reMu,imMu ;
    int nbIterationsMax ;

    // variable utiliser pour le tampon de l'image
    BufferedImage bi ;
    
    // constructeur 
    PanelGraph2(int ni, int nj) { 
	this.setPreferredSize(new Dimension(ni,nj)) ;
	dimImage = new Dimension(this.getPreferredSize()) ;
	System.out.println("/nnouveau PanelGraph") ;
	System.out.println("hauteur="+dimImage.getHeight()) ;	
	System.out.println("largeur="+dimImage.getWidth()) ;		
	//	bi = new BufferedImage((double)dimImage.getWidth(),
	//		       (double)dimImage.getHeight(),
	//		       BufferedImage.TYPE_INT_RGB) ;
	bi=new BufferedImage(500,500,BufferedImage.TYPE_INT_RGB) ;

	// initialisation des variables
	xmin=-2.0 ; xmax=2.0 ;
	ymin=-1.25 ; ymax=1.25 ;
	rayonCritique=5.0 ;
	nbIterationsMax=50 ;
	reMu=0.9 ; imMu=0.0 ;
    } // fin constructeur

    // methode qui genere l'image tampon (BufferedImage)

    public void genereImage() {
	
	// variables
	Graphics2D big ;
	int di,dj,i1,j1,i2,j2 ;
	float indice_couleur ;
	Color couleur ;
	Rainbow paletteArcEnCiel = new Rainbow() ;
	int indice_palette ;
	double valmin, valmax, valeur ;

	// on creer le graphique pour dessiner
	big=bi.createGraphics() ;

	// initialisation de certaines variables
	di=1 ; dj=1 ;
	valmin=0.0 ; valmax=(double)nbIterationsMax ;

	System.out.println("debut des calculs") ;
	// boucle sur les points
	i1=0  ;
	for (int i=0;i<dimImage.getWidth()-1;i++){
	    j1=0 ;
	    for (int j=0;j<dimImage.getHeight();j++){
		System.out.println("i,j="+i+","+j) ;
		// 
		valeur=calculeValeur(i,j) ;
		indice_couleur=(float)((valeur-valmin)/(valmax-valmin)) ;
		indice_palette=(int)(indice_couleur*255) ;
		couleur=paletteArcEnCiel.rgb[255-indice_palette] ;
		big.setColor(couleur) ;
		
		i2=i1+di ; j2=j1+dj ;
		
		big.fillRect(i1,j1,i2,j2) ;

		j1+=dj ;
	    } // fin boucle j
	    i1+=di ;
	} // fin boucle i
	System.out.println("fin des calculs") ;

	big.dispose() ;

    } // fin genereImage

   // methode qui repaint le panneau //
    
    public void paintComponent (Graphics g){
	super.paintComponent(g) ;
	update(g) ;
    }// fin paintComponent

    public void update (Graphics g){

	// variables
	Graphics2D g2 ;

	super.paintComponent(g) ;
	g2=(Graphics2D)g ;
	
	g2.drawImage(bi,null,0,0) ;

	System.out.println("passe dans update") ;
    } // fin update
    

    // methode calculeValeur
    public double calculeValeur(int i, int j) {
	
	// variables internes
	double x,y,dx,dy ;
	Complex z,mu ;
	double rayon ;
	int it=0;

	// initialisation
	dx=(xmax-xmin)/dimImage.getWidth() ;
	dy=(ymax-ymin)/dimImage.getHeight() ;
	
	// calcule des coord du centre du point
	x=xmin+(i+0.5)*dx ;
	y=ymin+(j+0.5)*dy ;

	z=new Complex(x,y) ;
	mu=new Complex(reMu,imMu) ;
	rayon=rayonCritique ;
	
	while (it < nbIterationsMax && rayon <= rayonCritique) {
	    z=z.times(z) ;
	    z=z.subtract(z,mu) ;
	    rayon=z.norm() ;
	    i++ ;
	}
	return (double)it ;
		
    } // fin calculeValeur

} // fin panelGraph2

// debut PanelGraph
class PanelGraph extends JPanel{
	 
    // grandeur image (en pixel)
    Dimension dimImage ;

    // def variables
    final int NiCalcul=500 ;
    final int NjCalcul=500 ;

    double [][] val = new double [NiCalcul][NjCalcul] ;
    double valmin, valmax ;

    BufferedImage bi = new BufferedImage(500,500,BufferedImage.TYPE_INT_RGB) ;
    
    // constructeur 
    PanelGraph(int ni, int nj) { 
	this.setPreferredSize(new Dimension(ni,nj)) ;
	dimImage = new Dimension(this.getPreferredSize()) ;
	System.out.println("/nnouveau PanelGraph") ;
	System.out.println("hauteur="+dimImage.getHeight()) ;	
	System.out.println("largeur="+dimImage.getWidth()) ;		
    }

    // methode qui genere l'image tampon (BufferedImage)

    public void genereImage(int largeur,int hauteur) {
	
	// variables
	Graphics2D big ;
	int di,dj,i1,j1,i2,j2 ;
	float indice_couleur ;
	Color couleur ;
	Rainbow paletteArcEnCiel = new Rainbow() ;
	int indice_palette ;
	//	BufferedImage bi = new BufferedImage(500,500,BufferedImage.TYPE_INT_RGB) ;
	big=bi.createGraphics() ;

	// partie qui fait le dessin
	di=(int)largeur/NiCalcul ;
	dj=(int)hauteur/NjCalcul ;
	
	// boucle sur les points
	i1=0  ;
	for (int i=0;i<NiCalcul-1;i++){
	    j1=0 ;
	    for (int j=0;j<NjCalcul;j++){
		// 
		indice_couleur=(float)((val[i][j]-valmin)/(valmax-valmin)) ;
		indice_palette=(int)(indice_couleur*255) ;
		couleur=paletteArcEnCiel.rgb[255-indice_palette] ;
		big.setColor(couleur) ;
		
		i2=i1+di ; j2=j1+dj ;
		
		big.fillRect(i1,j1,i2,j2) ;

		j1+=dj ;
	    } // fin boucle j
	    i1+=di ;
	} // fin boucle i

	big.dispose() ;

    } // fin genereImage

   // methode qui repaint le panneau //
    
    public void paintComponent (Graphics g){
	super.paintComponent(g) ;
	update(g) ;
    }// fin paintComponent

    public void update (Graphics g){

	// variables
	Graphics2D g2 ;

	super.paintComponent(g) ;
	g2=(Graphics2D)g ;
	
	g2.drawImage(bi,null,0,0) ;

	System.out.println("passe dans update") ;
    } // fin update
    


    // methodes qui calcule les points //
    
    public void calculeMandelbrot1() {
	
	// variables
	double xmin,xmax,ymin,ymax,dx,dy,x,y ;
	xmin=-2.0 ; xmax=2.0 ;
	ymin=-1.25 ; ymax=1.25 ;
	
	dx=(xmax-xmin)/NiCalcul ;
	dy=(ymax-ymin)/NjCalcul ;

	Complex z,zmoins ;
	double dist,epsilon=5. ;
	int NbIterationsMax=50 ;
	int it=0 ;

	valmin=0 ;
	valmax=(double)NbIterationsMax ;


	System.out.println("debut des calculs") ;
	// boucle sur tous les points
	for (int j=0;j<NjCalcul;j++){
	    for (int i=0;i<NiCalcul;i++){
		
		// calcule des coord du centre du point
		x=xmin+(i+0.5)*dx ;
		y=ymin+(j+0.5)*dy ;

		z=new Complex(x,y) ;
		dist=epsilon ;
		//debug System.out.println("iteration 0,z="+z.toString());
		it=0 ;

		while (it < NbIterationsMax && dist <= epsilon){
		    z=z.times(z) ;
		    z=z.subtract(z,0.9) ;
		    dist=z.norm() ;
		    it++ ;
		}
		val[i][j]=(double)it ;

		//debug System.out.println("point i,j="+i+" "+j);
		//debug System.out.println("x,y,val="+x+" "+y+" "+val[i][j]);
		
	    } // fin for sur i
	} // fin for sur j
	System.out.println("fin des calculs") ;
	
    }

} // fin panelGraph

