/*
programme pour tracer un graphique de mandelbrot
*/


import javax.swing.* ;
import java.awt.* ;
import java.awt.image.* ;
import java.io.* ;
import javax.imageio.* ;

public class Mandelbrot2 {

    // main
    public static void main(String[] args) {
	// creation du frame
	JFrame frame = new JFrame("Mandelbrot1") ;
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// creation du panel de base
	JPanel panelBase = new JPanel() ;
	frame.setContentPane(panelBase) ;
	
	// creation et addition des composantes
	
	JLabel label1 = new JLabel("bonjour") ;
	PanelGraph panel1 = new PanelGraph();
	panel1.setPreferredSize(new Dimension(500,500)) ;
	//panel1.calculePoints() ;
	panel1.calculeMandelbrot1() ;
	panel1.genereImage(500,500) ;

	panelBase.add(label1);
	panelBase.add(panel1);
	
	// on rend le frame visible
	
	frame.pack() ;
	frame.setVisible(true) ;
	
    } // fin main

} // fin Mandelbrot1

// debut PanelGraph
class PanelGraph extends JPanel{
	 
    // def variables
    final int NiCalcul=500 ;
    final int NjCalcul=500 ;

    double [][] val = new double [NiCalcul][NjCalcul] ;
    double valmin, valmax ;

    BufferedImage bi = new BufferedImage(500,500,BufferedImage.TYPE_INT_RGB) ;
    
    // methode qui genere l'image tampon (BufferedImage)

    public void genereImage(int largeur,int hauteur) {
	
	// variables
	Graphics2D big ;
	int di,dj,i1,j1,i2,j2 ;
	float indice_couleur ;
	Color couleur ;
	Rainbow paletteArcEnCiel = new Rainbow() ;
	int indice_palette ;
	//	BufferedImage bi = new BufferedImage(500,500,BufferedImage.TYPE_INT_RGB) ;
	big=bi.createGraphics() ;

	// partie qui fait le dessin
	di=(int)largeur/NiCalcul ;
	dj=(int)hauteur/NjCalcul ;
	
	// boucle sur les points
	i1=0  ;
	for (int i=0;i<NiCalcul-1;i++){
	    j1=0 ;
	    for (int j=0;j<NjCalcul;j++){
		// 
		indice_couleur=(float)((val[i][j]-valmin)/(valmax-valmin)) ;
		indice_palette=(int)(indice_couleur*255) ;
		couleur=paletteArcEnCiel.rgb[255-indice_palette] ;
		big.setColor(couleur) ;
		
		i2=i1+di ; j2=j1+dj ;
		
		big.fillRect(i1,j1,i2,j2) ;

		j1+=dj ;
	    } // fin boucle j
	    i1+=di ;
	} // fin boucle i

	// ecriture de l'image
	File file = new File("toto.jpg") ;
	try {
	    ImageIO.write(bi,"jpg",file) ;
	} catch(IOException e) {
	    System.out.println("coucou") ;
	} 

	big.dispose() ;

    } // fin genereImage

   // methode qui repaint le paneau //
    
    public void paintComponent (Graphics g){
	super.paintComponent(g) ;
	update(g) ;
    }// fin paintComponent

    public void update (Graphics g){

	// variables
	Graphics2D g2 ;

	super.paintComponent(g) ;
	g2=(Graphics2D)g ;
	
	g2.drawImage(bi,null,0,0) ;

	System.out.println("passe dans update") ;
    } // fin update
    


    // methodes qui calcule les points //
    
    public void calculeMandelbrot1() {
	
	// variables
	double xmin,xmax,ymin,ymax,dx,dy,x,y ;
	xmin=-2.0 ; xmax=2.0 ;
	ymin=-1.25 ; ymax=1.25 ;
	
	dx=(xmax-xmin)/NiCalcul ;
	dy=(ymax-ymin)/NjCalcul ;

	Complex z,zmoins ;
	double dist,epsilon=5. ;
	int NbIterationsMax=50 ;
	int it=0 ;

	valmin=0 ;
	valmax=(double)NbIterationsMax ;

	// boucle sur tous les points
	for (int j=0;j<NjCalcul;j++){
	    for (int i=0;i<NiCalcul;i++){
		
		// calcule des coord du centre du point
		x=xmin+(i+0.5)*dx ;
		y=ymin+(j+0.5)*dy ;

		z=new Complex(x,y) ;
		dist=epsilon ;
		//debug System.out.println("iteration 0,z="+z.toString());
		it=0 ;

		while (it < NbIterationsMax && dist <= epsilon){
		    z=z.times(z) ;
		    z=z.subtract(z,0.9) ;
		    dist=z.norm() ;
		    it++ ;
		}
		val[i][j]=(double)it ;

		//debug System.out.println("point i,j="+i+" "+j);
		//debug System.out.println("x,y,val="+x+" "+y+" "+val[i][j]);
		
	    } // fin for sur i
	} // fin for sur j
	
	
    }

} // fin panelGraph

