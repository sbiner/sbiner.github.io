
class maClasse {

    double toto ;
    double toto2 ;
    
    // constructeur
    maClasse(double toto) {
	toto2=toto ;
	this.toto=toto ;
	System.out.println("const maClase, toto="+toto) ;
	System.out.println("const maClase, toto2="+toto2) ;
    }

    // methode montre Toto
    void montreToto() { 
	System.out.println("montre Toto, toto="+toto) ;
	System.out.println("montre Toto, toto2="+toto2) ;
    }

}

public class testVariableScope {

    // main
    public static void main(String[] args) {
	double toto = 10. ;
	maClasse titi = new maClasse(toto) ;
	titi.montreToto() ;
    }

}
