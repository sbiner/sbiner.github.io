import java.util.ArrayList ;
import java.util.Iterator ;


public class Case
{

    public int i,j,iCarree,jCarree ; 
    public ArrayList valPoss = new ArrayList(9) ;


    // constructeur

    public Case(int i, int j)
    {
	//	System.out.println("debut construction case") ;
	this.i=i ;
	this.j=j ;
	
	this.iCarree=i/3 ;
	this.iCarree=j/3 ;

	for (int ii=1;ii<=9;ii++) {
	    //	    System.out.println("ii="+ii) ;
	    this.valPoss.add(ii-1,new Integer(ii)) ;
	}

	//	System.out.println(this.valPoss.toString()) ;
	//	System.out.println("fin construction case") ;
    }

    // methode d'affichage

    void printValPoss() {
	System.out.println("valPoss="+this.valPoss.toString()) ;
    }
    void printPos() {
	System.out.println("(i,j)=("+this.i+","+this.j+")") ;
    }
    void printCarree() {
	System.out.println("caree=("+this.iCarree+","+this.jCarree+")") ;
    }
	
    // methode pour assigner une valeur a une case

    void setValPoss(int val) {
	this.valPoss.clear() ;
	this.valPoss.add(new Integer(val)) ;
    }

    void setValPoss(int[] val) {
	int i ;
	valPoss.clear() ;
	for (i=0;i<val.length;i++) {
	    valPoss.add(new Integer(val[i])) ;
	}
    }


    // methode pour enlever une valeur a valPoss

    void enleveVal(Integer val) {
	int index ;
	if (valPoss.contains(val)) {
	    index=valPoss.indexOf(val) ;
	    valPoss.remove(index) ;
	}
    }

    void enleveVal2(int val) {
	int index ;
	if (valPoss.contains(new Integer(val))) {
		index=valPoss.indexOf(new Integer(val)) ;
		valPoss.remove(index) ;
	}
    }


    // methode pour enlever une valeur a valPoss si elle est dans une autre ArrayList

    void enleveValPoss(ArrayList liste) {
	Iterator i=liste.iterator() ;
	int index;
	Object val ;

	// boucle sur la liste a verifier
	while(i.hasNext()) {
	    val=i.next() ;
	    if (valPoss.contains(val)) {
		    // on enleve la valeur de valPoss
		    index=valPoss.indexOf(val) ;
		    valPoss.remove(index) ;
	    }
	}
    } // fin enleveValPoss


}
	    