class SudokuApp {
    public static void main(String[] args) {

	
	Grille maGrille = new Grille(9,9) ;
	maGrille.affiche();
	maGrille.test() ;
    }
}