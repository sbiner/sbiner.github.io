
import java.util.ArrayList ;
import java.util.Iterator ;

public class Grille
{
    int ni,nj ;
    Case [][] lesCases ;

    // constructeur

    public Grille(int ni, int nj) {

	Case laCase ;

	this.ni=ni ;
	this.nj=nj ;
	lesCases = new Case[ni][nj] ;

	// initialisation des cases
	for (int i=0;i<ni;i++) {
	    for (int j=0;j<nj;j++) {
		laCase=new Case(i,j) ;
		lesCases[i][j]=laCase ;
	    }
	}
    }

    // methode pour afficher la grille
    void affiche() {
	Case laCase ;

	System.out.println("on affiche la grille") ;
	for (int j=0;j<nj;j++) {
	    for (int i=0;i<ni;i++) {
		laCase=lesCases[i][j] ;
		laCase.printPos() ;
		laCase.printCarree() ;
		laCase.printValPoss() ;
	    }
	}
    }


    // methode pour assigner une valeur a une case
    void assigneVal(int i, int j, int val) {
	Case laCase ;

	laCase=this.lesCases[i][j] ;
	laCase.setValPoss(val) ;
    }

    // methode qui enleve les valeurs trouve des valeurs possible dans ligne, colonne et carree
    void analyse() {
	Case laCase , case2 ;
	ArrayList listeLigne = new ArrayList() ;
	ArrayList listeCol = new ArrayList() ;
	ArrayList listeCarree = new ArrayList() ;
	ArrayList listeTot = new ArrayList() ;
	Iterator it ;
	Integer valAEnlever ;

	// boucle sur les cases
	//debug
	/*
	for (int i=0;i<1;i++) {
	    for (int j=0;j<nj;j++) {
	*/

	for (int i=0;i<ni;i++) {
	    for (int j=0;j<nj;j++) {

		laCase=lesCases[i][j] ;

		// on batie la liste des cases dans meme lignes, colonne et carree
		listeLigne.clear() ;
		listeCol.clear() ;
		listeCarree.clear() ;
		listeTot.clear() ;

		for (int ii=0;ii<ni;ii++) {
		    for (int jj=0;jj<nj;jj++) {
			case2=lesCases[ii][jj] ;
			if (! case2.equals(laCase)) {
			    if (case2.i == i) { listeLigne.add(case2) ; }
			    if (case2.j == j) { listeCol.add(case2) ; }
			    if (case2.iCarree == laCase.iCarree && case2.jCarree == laCase.jCarree ) { listeCarree.add(case2) ; }
			}
		    }
		}

		// on batie la liste de toutes les cases dont la valeur, 
		// si elle est trouvee, ne peut etre dans valPoss
		listeTot.addAll(listeLigne) ;
		listeTot.addAll(listeCol) ;
		listeTot.addAll(listeCarree) ;

		// on enleve les valeurs trouvees de valPoss
		it = listeTot.iterator() ;
		while (it.hasNext()) {
		    case2=(Case)it.next() ;
		    if (case2.valPoss.size() == 1 ) {
			// on enleve la valeur de case2 de valPoss
			valAEnlever=(Integer)case2.valPoss.get(0) ;

			//debug
			/*
			System.out.println("on enleve "+valAEnlever+" de") ;
			laCase.printPos() ;
			System.out.println("car valeur de case") ;
			case2.printPos() ;
			*/
			laCase.enleveVal(valAEnlever) ;
		    }
		}


		// on enleve les valeurs multiples si possible
		// eg. si deux cases on [1,2] comme valeurs possibles, et qu'une
		//     autre a [1,2,3] c'est sur que la valeur de la 3e est 3.

		verifeValPossMultiples(laCase,listeLigne) ;
		verifeValPossMultiples(laCase,listeCol) ;
		verifeValPossMultiples(laCase,listeCarree) ;

	    }
	} // fin boucle sur les cases
    }// fin analyse
			    

    void verifeValPossMultiples(Case laCase,ArrayList listeCase) { 

	int nbValPoss ;
	ArrayList listeMemeValPoss = new ArrayList() ;
	ArrayList listeContientValPoss = new ArrayList() ;
	Iterator it ;
	Case case2 ;
	
	nbValPoss = laCase.valPoss.size() ;
	
	if (nbValPoss > 1) {
	    // on dresse la liste des cases possedant le meme valPoss
	    it = listeCase.iterator() ;
	    while (it.hasNext()) {
		case2=(Case)it.next() ;
		
		if (case2.valPoss.equals(laCase.valPoss)) {
		    listeMemeValPoss.add(case2) ;
		} else if (case2.valPoss.containsAll(laCase.valPoss)) {
		    listeContientValPoss.add(case2) ;
		}
	    }
	    // S'il y a autant de case avec les meme valPoss que le nombre de valPoss
	    // on peut enlever ces valPoss des cases dans ListeContientValPoss
	    
	    if ( listeMemeValPoss.size() == nbValPoss-1 && listeContientValPoss.size() > 0 ) {
		it=listeContientValPoss.iterator() ;
		while (it.hasNext()) {
		    case2=(Case)it.next() ;
		    case2.enleveValPoss(laCase.valPoss) ;
		}
	    }
	} // fin if
    } // fin verifeValPossMultiples
	

    // methode pour faire des tests
    void test() {

	Case laCase ;

	System.out.println("\nDebut test\n") ;


	laCase=lesCases[0][0] ;
	laCase.printPos() ;
	laCase.setValPoss(new int[] {1,2}) ;
	laCase.printValPoss() ;

	laCase=lesCases[0][1] ;
	laCase.printPos() ;
	laCase.setValPoss(new int[] {1,2}) ;
	laCase.printValPoss() ;
	
	laCase=lesCases[0][2] ;
	laCase.setValPoss(new int[] {1,2,3}) ;
	laCase.printPos() ;
	laCase.printValPoss() ;

	analyse() ;

	laCase=lesCases[0][0] ;
	laCase.printPos() ;
	laCase.printValPoss() ;

	laCase=lesCases[0][1] ;
	laCase.printPos() ;
	laCase.printValPoss() ;
	
	laCase=lesCases[0][2] ;
	laCase.printPos() ;
	laCase.printValPoss() ;
	


    }
}