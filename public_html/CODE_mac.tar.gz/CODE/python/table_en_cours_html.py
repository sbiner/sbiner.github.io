# programme qui a partir  d'un repertoire
# 1) va chercher sous-repertoires s'il y a des tables
# 2) va chercher la run en cours (s'il y a lieu)
# 3) batie une page web affichant l'evolution des runs en cours et
#    offrante des liens vers les tables de chaques runs s'il y a lieu
##################################################
#
# on change le path pour la recherche des modules pour inclure le path
# de HTMLgen
import sys
sys.path.append('/expl/biner/INFO/python_extra/HTMLgen')


from HTMLgen import *
#from HTMLcolors import *
import os.path
import string, time,sys
import HTMLcolors, barchart
##################################################
# definition de variables
liste_rep=os.listdir('.')

# lecture des arguments
for a in range(len(sys.argv)) :
    if a > 0 :
        if sys.argv[a] == '-rep' :
            rep=sys.argv[a+1]
            print 'en argument, -rep=',rep

dict_couleur={0:HTMLcolors.RED,999:HTMLcolors.ORANGE,1:HTMLcolors.GREEN}

print 'fin definition variables'
##################################################
# fonctions
def cherche_tables(liste_rep) :
    # fonction qui va voir dans les differents repertoires s'il y a une table
    import os.path
    import os

    liste_tables=[]
    for r in liste_rep :
        t='table_mrc_'+r
        path=os.path.join(r,t)
        if os.path.isfile(path) : liste_tables.append(path)
    return liste_tables
    
def lit_table(table) :
    # fonction qui retourne un dictionnaire contenant les informations
    # des differentes runs contenenues dans une tables
    # s'il y une table de timing correspondant on lit egalement les informations
    # du timing
    
    import string

    # on ouvre la table
    f=open(table)
    run=[]
    compteur=0
    # boucle sur les lignes de la table
    while 1:
        ligne=f.readline()
        if not ligne : break
        compteur=compteur+1
        # on lit les infos a partir de la 4e ligne
        if compteur >= 4 :
            ligne=string.split(ligne)
            nouv_run={}
            clef=['nom','lance','roule','fini','total','bombes','arch','diag','maj']
            valeur=ligne
            nouv_run=dict(zip(clef,ligne))
            run.append(nouv_run)

    # lecture des informations de timing si disponible
    table_timing=table+'.timing'
    if os.path.exists(table_timing) :
        f=open(table_timing)
        compteur=0
        while 1:
            ligne=f.readline()
            if not ligne : break
            compteur=compteur+1
            # on ajoute les infors dans run apres la 2e ligne
            if compteur >=  3 :
                ligne=string.split(ligne)
                clef=['lance_ini','lance_fini','roule_ini','roule_fini','arch_ini','arch_fini']
                del ligne[0] # on enleve la colonne avec le nom de la run
                val=ligne
                run[compteur-3].update(dict(zip(clef,val)))

    # on retourne les informations pour les differentes runs
    return run


def cherche_run_en_cours(liste_tables) :
    # fonction qui retourne un dictionnaire contenant pour une liste de table
    # le nom de la run qui est "en cours" (voir def dans la routine)
    liste_run_en_cours={}
    for table in liste_tables :
        # on lit les info de la serie de run pour chaque table
        serie_run=lit_table(table)

        nb_run_fini=0
        # on verifie s'il y a une run en cours et on compte le nombre de run finies
        for run in serie_run :
            if run['fini'] != run['total'] :
                run_en_cours=run.copy()
                break
            else : nb_run_fini=nb_run_fini+1
        # si toutes les runs sont finie, la run en cours est la derniere
        if nb_run_fini == len(serie_run) : run_en_cours=serie_run[-1].copy()
        
        # on ajoute a run_en_cours les informations du nombre de runs finies et du nombre total
        # de run a faire
        run_en_cours['nb_run_fini']=nb_run_fini
        run_en_cours['nb_run_total']=len(serie_run)
        
        # on ajoute la run en cours au dictionnaire
        liste_run_en_cours[table]=run_en_cours
    # on retourne le dictionnaire des runs en cours 
    return liste_run_en_cours

def fait_tableau_run_en_cours(table,run) :
    # fonction qui genere un tableau en format html illustrant
    # l'evolution de la serie de run d'une table
    #
    # note : Dans la version initiale la fonction retournait un tableau
    #        suite a des problemes de mise en pag, elle retourne plutot
    #        des lignes de tabeleau

    nb_run_total=run['nb_run_total']
    nb_run_fini=run['nb_run_fini']

    # on batie le tableau
    tab=TableLite()
    ligne=TR(bgcolor=HTMLcolors.GRAY2)
    ligne.append(TH('RUN',width=100))
    ligne.append(TH('LANCE',width=50))
    ligne.append(TH('ROULE',width=50))
    # on met la case tranche s'il y plus d'un tranche
    if int(run['total']) > 1 :
        ligne.append(TH('TRANCHES',width=50))
    texte=str(nb_run_fini)+'/'+str(nb_run_total)
    ligne.append(TH('EVOLUTION TOTALE ('+texte+')',width=150))
    tab.append(ligne)
    # on copie la ligne
    ligne1=ligne

    ligne=TR()
    r=run
    #
    # colonne run
    #
    table_web=table+'.html'
    print 'table_web=',table_web
    if os.path.exists(table_web) :
        # on fait un lien du nom de la run vers la page web de la serie
        cellule=Href(table_web,r['nom'])
    else : cellule=r['nom']
    ligne.append(TD(cellule))
    #
    # colonne lance
    #
    l=int(r['lance'])
    couleur=dict_couleur[l]
    # si timing on affiche l'info temporelle
    texte=RawText('&nbsp')
    if 'lance_ini' in r.keys() :
        if r['lance_ini'] != '' :
            t_fini=''
            if 'lance_fini' in r.keys() : t_fini=r['lance_fini']
            texte=affiche_timing(r['lance_ini'],t_fini)
            
    cellule=TD(texte,bgcolor=couleur,width=50)
    ligne.append(cellule)
    #
    # case roule
    #
    ro=int(r['roule'])
    # si roule=0 et fini=total, la run est fini
    if ro == 0 and r['fini'] == r['total'] : ro=1
    couleur=dict_couleur[ro]

    # si timing on affiche l'info temporelle
    texte=RawText('&nbsp')
    if 'roule_ini' in r.keys() :
        t_fini=''
        if 'roule_fini' in r.keys() : t_fini=r['roule_fini']
        if r['roule_ini'] != '' :
            texte=affiche_timing(r['roule_ini'],t_fini)

    cellule=TD(texte,bgcolor=couleur,width=50)
    ligne.append(cellule)
    #
    # case tranche
    #
    # on ne fait cette case que s'il y a plus d'une tranche
    if int(r['total']) > 1 : 
        # on rempli un tableau avec une case par tranche
        # tranches fini = vert
        # tranche  qui roule = orange
        # tranche  a faire = rouge
        texte=RawText('&nbsp')
        tableau_evolution=TableLite(width='100%',height='100%')
        ligne_evo=TR()
        # boucle sur les tranches
        for i in range(int(r['total'])) :
            if i < int(r['fini']) : couleur=dict_couleur[1]
            elif i > int(r['fini']) : couleur=dict_couleur[0]
            else : couleur=dict_couleur[int(r['roule'])]
            cellule=TD(texte,bgcolor=couleur)
            ligne_evo.append(cellule)
        tableau_evolution.append(ligne_evo)
        cellule=TD(tableau_evolution,height='100%')
        ligne.append(cellule)
    #
    # case evolution totale
    #
    texte=Font(size='-2')
    texte.append(RawText('&nbsp'))
    #tableau_evolution=TableLite(width='100%')
    tableau_evolution=TableLite()
    ligne_evo=TR()
    # boucle sur les run
    nb_run_par_ligne=60
    compteur=0
    for i in range(nb_run_total) :
        #print 'texte=',texte
        if i < nb_run_fini : couleur=dict_couleur[1]
        elif i > nb_run_fini : couleur=dict_couleur[0]
        else : couleur=dict_couleur[999]

        cellule=TD(texte,bgcolor=couleur)
        ligne_evo.append(cellule)
        # on saute un ligne si on a plus de run que la variable nb_run_par_ligne ou
        # si on a fini la boucle
        if compteur == nb_run_par_ligne or compteur == nb_run_total-1 :
            # on saute une ligne
            tableau_evolution.append(ligne_evo)
            ligne_evo=TR()
            compteur=0
        compteur=compteur+1

    cellule=TD(tableau_evolution,width='100%')
    ligne.append(cellule)

    # on ajoute la ligne
    tab.append(ligne)

    # on copie la ligne
    ligne2=ligne

    # on retourne le tableau
    #return tab

    # on retourne le ligne
    return ligne1,ligne2



def affiche_timing(t1,t2) :
    import time 

    font_timing=Font(size='-1')
    tl1=font_timing.copy()
    tl2=font_timing.copy()
    
    # modif selon l'info disponible
    if t1 == '' and t2 == '' : 
        tl1.append(RawText('&nbsp'))
        tl2.append(RawText('&nbsp'))
    elif t2 == '' :
        tl1.append('debut : '+t1)
        tl2.append(RawText('&nbsp'))
    else :
        format_temps='%d/%m/%Y_%Hh%M' # doit etre consequent avec ce qui est dans serie_edite_table.sh
#        format_temps='%Y/%m/%d/%H:%M'
        tt1=t1
        t1=time.strptime(t1,format_temps)
        t2=time.strptime(t2,format_temps)
        diff_temps=time.mktime(t2)-time.mktime(t1)
        diff_j=int(diff_temps/86400)
        diff_h=int(diff_temps/3600.)-diff_j*24
        diff_m=int(diff_temps/60.)-diff_h*60-diff_j*24*60
        etikj=''
        etikhm=''
        if diff_j > 0 : etikj="%i2" % (diff_j)
        etikhm="%02ih%02im" % (diff_h,diff_m)
        # formattage de la sortie
        tl1.append('debut : '+tt1)
        tl2.append('duree : '+etikhm)

    l1=TR(TD(tl1))
    l2=TR(TD(tl2))
    t=TableLite()
    t.append(l1,l2)
    sortie=t
    return sortie




        
##################################################
# programme

# on etablie la liste de tables 
print 'liste_rep=',liste_rep
liste_tables=cherche_tables(liste_rep)
print 'liste des tables :',liste_tables
# on va chercher quelles sont les runs en cours
liste_run_en_cours=cherche_run_en_cours(liste_tables)
for table in liste_run_en_cours.keys() :
    run_en_cours=liste_run_en_cours[table]
    print 'pour table ',table,' run en cours :',run_en_cours['nom']

# on genere la page montrant les informations au sujet des runs en cours

page_run_en_cours=SimpleDocument(bgcolor=HTMLcolors.CADETBLUE)
p=page_run_en_cours

# on ajoute l'option d'auto-rafraichissement de la table

frequ_rafraichissement=300
rafraichissement=Meta(equiv='Refresh',content=frequ_rafraichissement)
p.append(rafraichissement)


# affichage de la derniere mise a jour
font_maj=Font(size='-1')
texte_maj='derniere mise a jour:'+time.strftime('%d/%m/%Y %Hh%M',time.localtime())
font_maj.append(texte_maj)
p.append(Paragraph(font_maj,align='right'))

# titre
p.append(Heading(1,'Simulations en cours'))

# on ajoute les differentes simulations en cours
tableau=TableLite()
for table in liste_run_en_cours.keys() :
    run_en_cours=liste_run_en_cours[table]
    #tableau=fait_tableau_run_en_cours(table,run_en_cours)
    l1,l2=fait_tableau_run_en_cours(table,run_en_cours)
    tableau.append(l1)
    tableau.append(l2)    
#    p.append(tableau)

p.append(tableau)

texte='cette page se met automatiquement a jour a toutes les %3i s' % frequ_rafraichissement
p.append(Heading(3,texte))


# on ecrit la page

p.write('en_cours.html')
