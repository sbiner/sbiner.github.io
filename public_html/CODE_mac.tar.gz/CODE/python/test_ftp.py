from ftplib import FTP
import ftputil
import ftplib

from netrc import netrc
import sys
import string
import StringIO

s=StringIO.StringIO()

ntrc=netrc('/rhea/biner/.netrc')
login=ntrc.hosts['pharos2'][0]
pwd=ntrc.hosts['pharos2'][2]


pharos=ftputil.FTPHost('pharos2', login ,pwd)
pharos.chdir('/exec2/biner/roule/wt8/wt8_1995_m04_')
rep=pharos.getcwd()
liste=pharos.listdir(rep)
print rep
print liste
f=pharos.open('mrc_settings')
while 1 :
    line=f.readline()
    if not line : break
    print line,
    

## f=open('bidon','a')
## ftp=FTP('pharos2',login,pwd)
## ftp.cwd('/exec2/biner/roule/wt8/wt8_1995_m04_')
## ftp.dir()
## ftp.retrlines('retr outmrc_wt8_1995_m04_',s.write)
## for l in s.getvalue() :
##     if string.find('PAS',l) != -1 :
##         print l
        
