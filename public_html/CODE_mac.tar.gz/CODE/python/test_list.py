
liste1=['a','b','c']
liste2='abc'


def print1(liste) :
    print 'print1'
    for x in liste :
        print x

def print2(liste):
    print 'print2'

    if type(liste) is list :
        for x in liste :
            print x
    else :
        print liste

for liste in [liste1,liste2] :
    print liste
    print1([liste])
    print2([liste])
