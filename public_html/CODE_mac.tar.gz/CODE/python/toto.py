From Tkinter impor *

print "coucou"

def report():
	print "coucou"

object=Button(None,text="texte bouton",command=report)
object.pack() 
object.mainloop()
