# version orientee objet du programme permettant de generer des
# pages web a partir d'un repertoire contenant des images
#
# en construction


from biner import inverse_dico,uniq,etend_dico,classe_liste_dict,rend_liste
from biner_web import *
from string import *
from HTMLgen import *
import os.path
import string

##################################################

class Produit:
    """
    classe de base pour les produits disponibles pour le site web montrant la validation
    du MRCC
    """
    dico_source1={'O':'obs','M':'dm','P':'di'}
    dico_source2={'CU':'CRU','C2':'CRU2','P':'di','HP':'HOP','WM':'WM','NA':'na','W2':'WM2','LB':'Lieb','XI':'Xie','':''}
    dico_periode={'E':'ete','F':'automne','H':'hiver','P':'printemps'}
    dico_type_diff={'M' : 'diff moy' , 'R' : 'diff str'}
    dico_source1_inv=inverse_dico(dico_source1)
    dico_source2_inv=inverse_dico(dico_source2)
    dico_periode_inv=inverse_dico(dico_periode)
    dico_type_diff_inv=inverse_dico(dico_type_diff)
    # liste des attributs que les autres produits doivent avoir de
    # semblable a un produit donne pour etre juges semblables
    liste_attributs_a_tester=['periode','var','niv','source1','type','periode_validite']
    liste_type_affiche_source2=['diff str','diff moy']

    def __init__(self) :
        self.var=''
        self.niv='surface'
        self.source1=''
        self.source2=''
        self.fichier_img=''
        self.fichier_htm=''
        self.periode=''
        self.type=''
        self.etiquette=''
        self.rep_img=''
        self.rep_htm=''
        self.unites=''
        self.periode_validite=''

    # on definie quand deux produits sont pareils

    def __eq__(self,autre) :
        
        liste_attributs_a_tester=[]
        for att in self.__dict__.keys() :
            if att not in ['rep_htm','rep_img'] : liste_attributs_a_tester.append(att)

        sortie=1
        for att in liste_attributs_a_tester :
            att_self=getattr(self,att)
            att_autre=getattr(autre,att)
            if att_self != att_autre :
                sortie=0
                break
        return sortie

    def decode_fichier_img(self) :
        """
        fonction qui decode les attribut du produit selon le nom du fichier_img
        """
        # on verifie la validite du nom du fichier est valide
        if self.valide_fichier_img() :
            # on traite les champs autre que BLT
            if self.fichier_img[0:3] == 'blt' :
                print 'cas non traite pour l\'instant'
            else :
                #
                # fichiers autres que BLT
                #
                self.var,code,niveau=split(self.fichier_img,'_')
                #on enleve l'extension
                niveau,bidon=os.path.splitext(niveau)
                #on cherche le type du fichier
                ii_moy=find(code,'MOY')
                ii_str=find(code,'STR')
                if ii_moy != -1 :
                    type='moy'
                    indice=ii_moy
                elif ii_str != -1 :
                    type='str'
                    indice=ii_str
                else :
                    type='diff'
                # selon le type on decode les autres informations
                if type == 'moy' or type == 'str' :
                    source_base=Produit.dico_source1[code[0]]
                    if source_base != 'obs' :
                        # cas pilote ou modele
                        run=code[1:indice]
                        self.source1=source_base+run
                    else :
                        # cas obs
                        obs=Produit.dico_source2[code[1:indice]]
                        self.source1=source_base+obs
                    self.source2=''
                    self.periode=Produit.dico_periode[code[-1]]
                    self.type=type
                else :
                    source_base=Produit.dico_source1[code[0]]
                    run=code[1:4]
                    self.source1=source_base+run
                    source2=Produit.dico_source2[code[4:-2]]
                    if source2 == 'di' : source2=source2+run
#debug
                    else : source2='obs'+source2
                    self.source2=source2
#                    type_diff=Produit.dico_type_diff[code[-2]]
#                    self.type='diff '+type_diff
                    self.type=Produit.dico_type_diff[code[-2]]
 
                    self.periode=Produit.dico_periode[code[-1]]

                # on decode le niveau
                self.niv=niveau[:-2]
                # on decode la periode de validite
                rep=self.rep_img
                for f in os.listdir(rep) :
                    if source_base in ['obs','dm'] and f[:3] == '.DM' : self.periode_validite=f[4:]
                    elif source_base in ['di'] and f[:3] == '.DI' : self.periode_validite=f[4:]
                # on s'assure qu'un periode de validite est trouvee
                if self.periode_validite == '' :
                    print 'PROBLEME'
                    print 'il manque les fichier .DI_* et .DM_* dans ',rep
                    raise PeriodeValiditeManquante
        else :
            print self.fichier_img+" non valide, fichier ignore"
            

    def fichier_img_est_present(self) :
        """
        fonction qui retourne 1 si le fichier_img correspondant a un produit
        est present et 0 si ce n'est pas le cas
        """
        import copy
        bidon=copy.copy(self)
        f=os.path.join(bidon.rep_img,bidon.fichier_img)
        if os.path.exists(f) :
            return 1
        else :
            return 0

    def maj_fichier_htm(self) :
        """
        fonction qui change la valeur de fichier_htm pour la meme chose que fichier_img mais
        en changeant le suffixe html
        """
        import os.path
        fichier,suff=os.path.splitext(self.fichier_img)
        self.fichier_htm=fichier+'.html'

    def encode_fichier_img(self) :
        """
        fonction qui trouve le nom du fichier_img selon les attributs du produit 
        """
        # on trouve le code pour la source1
        if self.source1[:2] == 'dm' : code_source1='M'+self.source1[2:]
        if self.source1[:2] == 'di' : code_source1='P'+self.source1[2:]
        if self.source1[:3] == 'obs' : code_source1='O'+self.dico_source2_inv[self.source1[3:]]

        #traitement selon le type
        if self.type == 'moy' or self.type == 'str' :
            # code_type='MOY' ou 'STR'
            code_type=string.upper(self.type)
            code_source2=''
        elif self.type == 'diff moy' or self.type == 'diff str' :
            # on trouve le code pour le type
            code_type=Produit.dico_type_diff_inv[self.type]
            # on trouve le code pour source2 : P, CU, C2, ...
            clef_source2=self.source2
            if clef_source2[:2] == 'di'  :
                # source 2 est le pilote
                clef_source2=clef_source2[:2]
#debug
            else : clef_source2=clef_source2[3:]
                
            code_source2=Produit.dico_source2_inv[clef_source2]
        # on trouve le code de la periode
        code_periode=Produit.dico_periode_inv[self.periode]
        # on trouve code pour le niveau
        code_niv=self.niv+'mb'
        # on batit le nom du fichier
        self.fichier_img=self.var+'_'+code_source1+code_source2+code_type+code_periode+'_'+code_niv+'.gif'


    def valide_fichier_img(self) :
        """
        fonction qui s'assure qu'un nom de fichier_img est valide
        """
        f=self.fichier_img
        garde=1
        # on verifie que f ne debute pas par un "."
        if f[0] == '.' : garde=0
        # on verifie que l'extenstion et .gif
        if os.path.splitext(f)[1] not in ['.gif'] : garde=0
        # on verifie que f ne debute pas par 'blt'
        if f[0:3] in ['blt','BLT'] : garde=0
        # on retourne garde
        return garde

    def affiche(self) :
        """
        fonction qui affiche tous les attributs du produit
        """
        liste_attributs=['var','niv','source1','source2','fichier_img','fichier_htm', \
                         'rep_img','rep_htm','periode','type','etiquette','periode_validite']
        print "\n"+'-'*50
        for a in liste_attributs :
            print a,'=',getattr(self,a)
        print "\n"+'-'*50

    def trouve_autres_produits(self,liste_prod,clef) :
        """
        fonction qui pour un produit va chercher dans une liste de produits
        ceux qui sont identique sauf pour l'argument clef. La verification est
        faite sur les arguments dans la liste Produit.liste_attributs_a_tester.

        e.g. pour aller chercher les autres periode d'un produit p taper :
        liste=p.trouve_autres_produits(liste_prod,'periode')
        liste contiendra une liste de produits contenant des produits semblables a p sauf pour la periode.

        """
        if clef not in Produit.liste_attributs_a_tester :
            print 'clef \"'+clef+'\" invalide dans trouves_autres'
            return []
        
        liste=[]
        for p in liste_prod :
            garde=1
            # on boucle sur tous les attributs a tester
            for attr in Produit.liste_attributs_a_tester :
                attr_self=getattr(self,attr)
                attr_p=getattr(p,attr)

                # cas ou l'attribut n'est pas la clef
                if attr != clef :

                    # on verifie si l'attribut est pareil
                    if attr_self != attr_p :
                        garde=0
                        break
                    # dans certains cas il faut aussi que source2 soit pareil
                    if attr in self.liste_type_affiche_source2 or \
                           self.type in self.liste_type_affiche_source2 :
                        if getattr(self,'source2') != getattr(p,'source2') :
                            garde=0
                            break

                # cas ou l'attribut est la clef
                else :
                    if attr_self == attr_p :
                        # le produit est identique
                        garde=0
                        break
                
            if garde :
                # on verifie qu'un produit semblable n'est pas deja dans la liste avant de l'ajouter a la liste
                for prod_deja_dans_liste in liste :
                    if prod_deja_dans_liste == p :
                        garde=0
                        break
                if garde : liste.append(p)
        return liste

    def trouve_autres_produits2(self,liste_prod,clef) :

        # ajustement de la liste des attributs a tester selon les cas
        liste_attributs_a_tester=['var','niv','periode','source1','type']
        if self.type in ['diff str','diff moy'] and \
               clef != 'type' :
            liste_attributs_a_tester.append('source2')

        # on verifie que la clef est admissible
        if clef not in liste_attributs_a_tester :
            print 'clef \"'+clef+'\" invalide dans trouves_autres'
            raise ClefInvalide
        
        liste=[]
        for prod in liste_prod :
            garde=1
            # on boucle sur tous les attributs a tester
            for attr in liste_attributs_a_tester :
                attr_self=getattr(self,attr)
                attr_prod=getattr(prod,attr)
                # on ne teste pas la clef
                if attr != clef :
                    if attr_self != attr_prod :
                        garde=0
                        break
            # si le produit est semblable, on verifie qu'il n'est pas identique
            clef_self=getattr(self,clef)
            clef_prod=getattr(prod,clef)
            if garde and clef_self == clef_prod :
                # les produits sont identiques
                garde=0

            # on est pret a ajouter le produit a la liste
            if garde :
                # on verifie qu'un produit semblable n'est pas deja dans la liste avant de l'ajouter a la liste
                for prod_deja_dans_liste in liste :
                    if prod_deja_dans_liste == prod :
                        garde=0
                        break
                if garde : liste.append(prod)
        return liste

class ListeProduits :
    """
    classe de base pour traiter une liste de produits.

    Les methodes batissent la liste des produits disponibles, en affiche
    et traite l'inventaire, et genere des pages web pour les regarder
`    """
    from wd1 import Produit
    import HTMLcolors
    
    # variable interne

    # liste des type pour lesquels on affiche source2 lorsqu'on propose des produits semblables
    liste_type_affiche_source2=['diff str','diff moy']

    # valeur par defaut
    rep_recherche='.'
    liste_produits=[]

    def __init__(self, *arg, **kw) :
        for name, value in kw.items() :
            setattr(self,name,value)
            print 'valeur attribut ',name,' = ',getattr(self,name)
            
    ##### SECTION TRAITEMENT DES PRODUITS #####


    def cherche_produits(self) :
        """
        methode qui cherche dans des repertoires et bati un liste avec les produits disponibles

        La recherche se fait dans le repertoire rep_recherche
        Par defaut rep_recherche='.'
        Si rep_recherche='.' on cherche aussi dans les repertoires sous-jascent (1 niveau seulement)
        
        """
        import os
        import os.path

        # on batit la liste de repertoire a fouiller selon la valeur de rep_recherche
        if self.rep_recherche != '.' :
            liste_rep=rend_liste(self.rep_recherche)
        else :
            # on va chercher les repertoire contenus dans .
            liste_rep=[]
            for d in os.listdir(self.rep_recherche) :
                if os.path.isdir(d) : liste_rep.append(d)

        # on boucle sur les repertoire et on dresse une liste des produits disponibles.
        liste_produits=[]
        for rep in liste_rep :
            print '*****'
            print 'on cherche dans le repertoire ',rep
            print '*****'
            # boucle sur les fichiers du repertoire
            liste_fichiers=os.listdir(rep)
            for f in liste_fichiers :
                bidon=Produit()
                bidon.rep_img=rep
                bidon.fichier_img=f
                # si le nom de fichier semble valide, on le decode et
                # on ajoute le produit a la liste
                if bidon.valide_fichier_img() :
                    bidon.decode_fichier_img()
                    print 'fichier ',f,' valide'
                    # tout est beau, on ajoute le produit a la liste
                    liste_produits.append(bidon)
        # on s'assure d'eviter les repetitions
        self.liste_produits=liste_produits


    def extrait_produits(self,liste_entree,dict_recherche) :
        """

        fonction qui cherche dans liste_entree les produits
        correspondant a dict_recherche. Les produits trouves sont
        retournes en sortie

        dict_recherche contient des clefs et des valeurs

        e.g. pour chercher les produit de type='aaa' et de periode='ete'

        dict_recherche={'type':'aaa','periode':'ete'}
        liste_sortie=extrait_produits(liste_entree,dict_recherche)

        ou

        liste_sortie=extrait_produits(liste_entree,{'type':'aaa','periode':'ete'})
        
        """
        liste_sortie=[]
        for p in liste_entree :
            garde=1
            for c in dict_recherche.keys() :
                if hasattr(p,c) :
                    # on rend dict_recherche liste pour le loop
                    dict_recherche[c]=rend_liste(dict_recherche[c])
                    if getattr(p,c) in dict_recherche[c] :
                        garde=1
                    else :
                        garde=0
                        break
                else :
                    garde=0
                    break
            if garde == 1 : liste_sortie.append(p)
        
        return liste_sortie


    def affiche_inventaire(self,liste_entree,*args) :
        """
        fonction qui affiche l'inventaire d'une liste a l'ecran

        On peu mettre une liste d'argument qui decrira les elements a afficher

        e.g. si on veut afficher l'inventaire des source1 et type dans liste_entree on
             taperait :

             affiche_invenaire(liste_entree,['source1','type'])

        """
        # si des clefs sont passe en argument on restreint l'inventaire a ces clefs
        if len(args) > 0 :
            liste_clefs=args
        else :     
            # on affiche tout ce qu'il y a dans liste_produits
            liste_clefs=['var','niv','source1','source2','periode','type','periode_validite']

        dico={}
        # on initalise le dictionnaire de sortie pour toutes les clefs
        for c in liste_clefs :
            dico[c]=[]
        # on batit la liste d'inventaire
        for p in liste_entree :
            for c in liste_clefs :
                liste=dico[c]
                liste.append(getattr(p,c))
                dico[c]=uniq(liste)
        # on affiche la liste d'inventaire
        print '***** INVENTAIRE *****'
        for c in liste_clefs :
            print 'liste de ',c,'=',dico[c]
        print '**********************'


    def fait_inventaire(self,liste,*args) :
        """
        fonction qui genere un dictionnaire avec l'inventaire d'une liste

        On peu mettre une liste d'argument qui decrira les elements voulu

        e.g. si on veut avoir l'inventaire des source1 et type dans liste_entree on
             taperait :

             inventaire=fait_invenaire(liste_entree,'source1','type')

        """
        # si des clefs sont passe en argument on restreint l'inventaire a ces clefs
        if len(args) > 0 :
            # transfo de tuple a liste
            liste_clefs=[]
            for i in args : liste_clefs.append(i) 
        else :     
            # on affiche tout ce qu'il y a dans liste_produits
            liste_clefs=['var','niv','source1','source2','periode','type','periode_validite']

        dico_sortie={}
        # on initalise le dictionnaire de sortie pour toutes les clefs
        for c in liste_clefs :
            dico_sortie[c]=[]
        # on ajoue les elements au dictionnaire
        for p in liste :
            for c in liste_clefs :
                l=dico_sortie[c]
                l.append(getattr(p,c))
                dico_sortie[c]=uniq(l)
        # on retourne le dictionnaire contenant l'inventaire
        return dico_sortie

    #### SECTION PAGE HTML #####

    page_base=SimpleDocument(bgcolor=HTMLcolors.CADETBLUE)
    couleur_entete_tableaux=HTMLcolors.ORANGE
    
    def fait_page_menu(self,liste,**kw) :

        import HTMLcolors
        
        """
        methode qui fait une page web a partir d'une liste de produit disponible
        
        fait_page_menu([fichier='','crit_menu='','crit_tab=''])

        defauts :
        fichier='menu.html'
        crit_menu='source1' # critere ayant servi a faire le menu
        crit_tab='type'     # critere communs aux produits de chaque tableaux
        """

        # valeur par defaut
        crit_menu='source1'    # critere du produit commun a tous les produits du menu
        crit_tab='type'        # critere commun aux produits presents dans le meme tableau
        fichier='menu.html'  # nom du fichier de sortie

        # valeurs passees en argument
        for name, value in kw.items() :
            if name == 'crit_menu' : crit_menu=value
            if name == 'crit_tab' : crit_tab=value
            if name == 'fichier' : fichier=value

        # on regarde les valeurs possibles pour le critere crit_menu
        # dans la liste d'entree. S'il y en a plus d'une on ajuste
        # l'indicateur ajout_crit_menu=1 pour ajouter crit_menu dans
        # l'entete des tableaux
        #
        # Par exemple, si on fait un menu des dm et di d'une run, on
        # veut ajouter l'attribut source1 aux tableaux. Par contre si
        # on ne fait que le menu des dm on ne mettra pas cette
        # attribut dans les tableaux car il est commun a tous les
        # produits
        
        ajoute_crit_menu=0
        if len(self.fait_inventaire(liste,crit_menu)[crit_menu]) > 1 : ajoute_crit_menu=1

        ##########
        # generation de la page web

        #####
        # on met l'entete
        entete=Entete()
        
        # on ajoute le titre
        val_crit_menu=getattr(liste[0],crit_menu)
        texte=Heading(2,'Menu pour les produits dont '+crit_menu+'=',val_crit_menu,align='center')
        entete.append(texte)
        
        # on dresse la liste des tableaux qui vont etre affiches et on ajoute leur liens dans
        # l'entete
        self.affiche_inventaire(liste)
        liste_tableaux=self.fait_inventaire(liste,crit_tab)
        for t in liste_tableaux[crit_tab] :
            lien=Href('#'+t,Font('tableau '+t,size='-1'))
            entete.ajoute_lien_entete(lien)

        #####
        # tableaux

        page_tableaux=SimpleDocument()
        # on ajoute les tableaux
        for tab in liste_tableaux[crit_tab] :


            # ancre, lien vers entete et nom du tableau
            page_tableaux.append(HR())
            page_tableaux.append(Name(tab))
            page_tableaux.append(entete.lien_vers_entete)
            page_tableaux.append(Heading(3,tab))

            # on extrait la liste des produits du tableau
            dico={crit_tab:tab}
            liste_du_tableau=self.extrait_produits(liste,dico)
            dico_entete=self.fait_inventaire(liste_du_tableau)

            # initalisation du tableau
            tableau=TableLite()

            # on fait l'entete du tableau
            ligne1=TR(bgcolor=self.couleur_entete_tableaux)
            # si plus d'une periode et periode dans l'entete, il y deux ligne
            nb_ligne=1
            nb_periode=len(dico_entete['periode'])
            if nb_periode > 1 and 'periode' != crit_tab :
                nb_ligne=2
                ligne2=TR(bgcolor=self.couleur_entete_tableaux)
                
            # on initalise les infos sur les colonnes du tableau
            colonne=[]
            # traitement particulier selon les attributs du produit
            liste_entete=['var','source1','source2','periode','niv','type']

            for attribut in liste_entete :
                # on ne met pas dans l'entete d'attribut commun au tableau
                if attribut != crit_tab and attribut in dico_entete.keys() :
                    # on peut mettre dans l'entete l'attribut du menu
                    # (voir commentaire a l'initalisation de la clef
                    # ajoute_crit_menu
                    if attribut != crit_menu or ajoute_crit_menu :
                        
                        # cas particulier des periodes
                        if attribut == 'periode' :
                            # on met toutes les periodes sur la meme ligne
                            if nb_ligne == 2 :
                                ligne1.append(TH('periode',colspan=nb_periode))
                                for s in dico_entete['periode'] :
                                    ligne2.append(TH(s))
                                    colonne.append({'periode':s,'attribut':attribut})
                            else :
                                ligne1.append(TH(dico_entete['periode']))
                                colonne.append({'attribut':attribut})

                        # autres attributs
                        else :
                            ligne1.append(TH(attribut,rowspan=nb_ligne))
                            colonne.append({'attribut':attribut})


            # on insere l'entete dans le tableau
            tableau.append(ligne1)
            if nb_ligne == 2 : tableau.append(ligne2)
            
            # on bati la liste de tous les produits possibles selon l'entete
            dico_possible={}
            for col in colonne :
                attr=col['attribut']
                # on enleve la periode des critere car on met toute les periodes sur une ligne
                if attr != 'periode' :
                    dico_possible.update(self.fait_inventaire(liste_du_tableau,attr))
            liste_possible=etend_dico(dico_possible)

            #on classe la liste de possibilite selon la premiere colonne
            liste_possible=classe_liste_dict(liste_possible,colonne[0]['attribut'],1)

            #on passe a travers toute les possibilites
            for poss in liste_possible :
                liste_prod=self.extrait_produits(liste_du_tableau,poss)

                if len(liste_prod) > 0 :
                    # la possibilite est trouvee dans les produits
                    # on garde le premier produit comme produit type
                    prod_type=liste_prod[0]
                    # on creer la ligne
                    ligne=TR()
                    # boucle sur les colonnes
                    for col in colonne :
                        attr=col['attribut']
                        # si colonne autre que periode on ecrit la valeur de l'attribut
                        if attr != 'periode' :
                            texte=getattr(prod_type,attr)
                            cellule=TD(texte)
                        else :
                            # si colonne periode, on met les liens vers
                            # les pages si les produits sont
                            # disponibles
                            
                            # on bati un dico pour voir s'il y un produit correspondant
                            periode=col['periode']
                            dic_recherche={'periode':periode}
                            dic_recherche.update(poss)
                            liste_bidon=self.extrait_produits(liste_du_tableau,dic_recherche)
                            if len(liste_bidon) > 0 :
                                # le produit est disponible, on ajoute le lien
                                produit_bidon=liste_bidon[0]
                                lien=produit_bidon.fichier_htm
                                cellule=TD(Href(url=lien,text='ici'),bgcolor=HTMLcolors.GREEN,align='center')
                            else :
                                # le produti n'y est pas
                                cellule=TD('ND',bgcolor=HTMLcolors.RED,align='center')
                        ligne.append(cellule)
                    # on ajoute la ligne au tableau
                    tableau.append(ligne)

            # on insere le tableau dans la page
            page_tableaux.append(tableau)
            
            

        # fin boucle sur liste_tableaux

        # on ecrit la page web
        page=self.page_base.copy()
        entete.termine()
        page.append(entete)
        page.append(page_tableaux)
        page.write(fichier)
        

    def fait_page_moy_str(self,produit,liste_produits,fichier) :
        """
        methode qui genere la page web pour montrer les produits de type moy et str

        appel :  fait_page_moy_str(produit,liste_produits)

        la liste liste_produits est la liste consultee pour dresser la liste des produits similaires

        """
        import HTMLcolors
        import copy
        
        # on ajoute l'entete
        entete=Entete()

        # page avec l'image
        page_image=SimpleDocument()
  
        # on bati le tableau avec les info et les autres produits disponibles
        tab_d=TableLite()
        nb_ligne=0
        # ajout des info a cote de l'image
        ligne=TR()
        ligne.append(TH('info sur produit',bgcolor=HTMLcolors.ORANGE))
        tab_d.append(ligne)
        info_image=['var','source1','periode','niv','type']
        for x in info_image :
            val=getattr(produit,x)
            texte=x+'='+val
            ligne=TR()
            ligne.append(TH(x))
            ligne.append(TD(val,align='left'))
            tab_d.append(ligne)
            nb_ligne+=1
        # ajoute liens vers produits semblables
        liste_attributs=['var','periode','type','source1']
        if produit.type in self.liste_type_affiche_source2 :
            liste_attributs.append('source2')
        entete_mise=0

        for a in liste_attributs :
            liste_autres=produit.trouve_autres_produits2(liste_produits,a)
            if len(liste_autres) > 0 :
                # on ajoute l'entete
                if entete_mise == 0 :
                    tab_d.append(TR(TH('produits semblables disponibles',bgcolor=HTMLcolors.ORANGE)))
                    nb_ligne+=1
                    entete_mise=1
                # on ajoute les liens vers les produits semblables
                ligne=TR()
                ligne.append(TH(a))

                for prod in liste_autres :

                    val=getattr(prod,a)
                    # on verifie s'il faut ajouter source2 au texte
                    if val in self.liste_type_affiche_source2 :
                        texte=val+' '+prod.source2
                    else :
                        texte=val

                    lien=prod.fichier_htm
                    ligne.append(TD(Href(url=lien,text=texte)))
                # ajout de la ligne 
                tab_d.append(ligne)
                nb_ligne+=1
        # on complete le tableau
        tab_d.append(TR())
        nb_ligne+=1
                
        # on ajoute l'image
        tab_g=TableLite()
        image=Image(os.path.join(produit.rep_img,produit.fichier_img))
        tab_g.append(TR(TD(image,rowspan=nb_ligne)))

        # on joint les deux tableaux et on les met sur la page
        tableau=TableLite()
        ligne=TR()
        ligne.append(TD(tab_g))
        ligne.append(TD(tab_d,valign='top'))
        tableau.append(ligne)
        page_image.append(tableau)
        
        
        # on ecrit la page
        page=self.page_base.copy()
        entete.termine()
        page.append(page_image)
        page.append(entete)
        page.write(fichier)

    def fait_page_diff(self,produit,liste_produits,fichier) :
        """
        methode qui genere les page web pour les differences

        appel : fait_page_diff(produit,liste_produits,fichier)

        la liste liste_produits est consultee pour dresser la liste
        des produits semblables
        """
        import HTMLcolors
        import copy

        # on genere le tableau avec les info sur l'image et sur les autres produits semblables
        tab_info=TableLite()
        # ajout des info a cote de l'image
        ligne=TR()
        ligne.append(TH('info sur produit',bgcolor=HTMLcolors.ORANGE))
        tab_info.append(ligne)
        info_image=['var','source1','source2','periode','niv','type']
        for i in info_image :
            val=getattr(produit,i)
            ligne=TR()
            ligne.append(TH(i))
            ligne.append(TD(val,align='left'))
            tab_info.append(ligne)
        # ajout des liens vers produits semblables
        liste_attributs=['var','periode','type','source1']
        if produit.type in self.liste_type_affiche_source2 :
            liste_attributs.append('source2')

        entete_mise=0
        for a in liste_attributs :
            liste_autres=produit.trouve_autres_produits2(liste_produits,a)

            if len(liste_autres) > 0 :

                # on ajoute l'entete
                if entete_mise == 0 :
                    texte='produits semblables disponibles'
                    tab_info.append(TR(TH(texte,bgcolor=HTMLcolors.ORANGE)))
                    entete_mise=1

                # on remplie la ligne
                ligne=TR()
                ligne.append(TH(a))
                for prod in liste_autres :

                    val=getattr(prod,a)
                    
                    # on verifie s'il faut ajouter source2 au texte
                    if val in self.liste_type_affiche_source2 :
                        texte=val+' '+prod.source2
                    else :
                        texte=val
                    
                    lien=prod.fichier_htm
                    ligne.append(TD(Href(url=lien,text=texte)))
                # ajout de la ligne au tableau
                tab_info.append(ligne)

        #ajout des images
        taille_img=500

        # image de la diff
        tab_diff=TableLite()
        img_grand=os.path.join(produit.rep_img,produit.fichier_img)
        img=Image(os.path.join(produit.rep_img,produit.fichier_img),width=taille_img)
        lien=Href(url=img_grand)
        lien.append(img)
        tab_diff.append(TR(TD(lien)))
        
        #image de source1 et source2
        tab_s=[]
        for s in ['source1','source2'] :
            dico_transfo_type={'diff str':'str','diff moy':'moy'}
            produit_bidon=copy.copy(produit)
            produit_bidon.type=dico_transfo_type[produit.type]
            if s == 'source2' : produit_bidon.source1=produit.source2
            produit_bidon.source2=''
            produit_bidon.encode_fichier_img()
            produit_bidon.maj_fichier_htm()
            # si le fichier img cherche est present on ajoute l'image
            # on fait la recherche dans le basename de rep_img
            rep_img_original=produit_bidon.rep_img
            bidon,produit_bidon.rep_img=os.path.split(rep_img_original)
            if produit_bidon.fichier_img_est_present() :
                # on retablie rep_img pour que lien suive comme il faut
                produit_bidon.rep_img=rep_img_original
                img_grand=os.path.join(produit_bidon.rep_img,produit_bidon.fichier_img)
                img=Image(os.path.join(produit_bidon.rep_img,produit_bidon.fichier_img),width=taille_img)
                # on fait le lien entre img et img_grand
                # si on clique sur img, img_grand est affichee
                lien=Href(url=img_grand)
                lien.append(img)
                tab=TableLite()
                tab.append(TR(TD(lien)))
                texte='champ pour '+produit_bidon.source1
                tab.append(TR(TH(texte)))
                tab_s.append(tab)
            else :
                texte='champ pour '+produit_bidon.source1+' N/D'
                tab=TableLite()
                tab.append(TR(TH(texte)))
                tab_s.append(tab)

        # ajout des tableau a la page
        page_image=SimpleDocument()
        tableau=TableLite()
        ligne=TR()
        ligne.append(TD(tab_diff))
        ligne.append(TD(tab_info,valign='top'))
        tableau.append(ligne)
        ligne=TR()
        for tab in tab_s :
            ligne.append(TD(tab))
        tableau.append(ligne)
        page_image.append(tableau)

        # ecriture de la page web
        page=self.page_base.copy()
        page.append(page_image)
        texte='Si les images sont degradees, cliquez dessus afin de les agrandir'
        page.append(texte)
        entete=Entete()
        entete.termine()
        page.append(entete)
        page.write(fichier)

    def fait_page_accueil(self,liste,rep_web,fichier) :
        """
        methode qui genere la page d'accueil

        appel fait_page_accueil(liste,fichier)

        """
        import os.path
        
        page_liste='page_liste.html'
        page_accueil='page_accueil.html'

        page=FramesetDocument(title='DIAG DU MRCC')
        frame0=Frameset(cols='150,*')
        # frame de gauche
#        frame_g=Frameset() 
        frame_g=Frame(src=page_liste,frameborder=0,scrolling='auto')
#        frame_g.append(frame_g1)

        # frame de droite
#        frame_d=Frameset()
        frame_d=Frame(src=page_accueil,frameborder=0,scrolling='auto',name='affichage')
#        frame_d.append(frame_d1)

        # ajout de frame_g et frame_d
        frame0.append(frame_g)
        frame0.append(frame_d)

        # ecriture de la page
        page.append(frame0)
        page.write(os.path.join(rep_web,fichier))

        # on genere page_liste
        page=SimpleDocument()
        page.append(Heading(2,'DIAG MRCC'))
        page.append(HR())
        page.append(Heading(2,'liste des menus'))
        page.append(HR())
        tab=TableLite()
        for m in liste :
            lien='menu_'+m+'.html'
            tab.append(TR(TD(Href(url=lien,text=m,target='affichage'))))

        page.append(tab)
        page.write(os.path.join(rep_web,page_liste))

        # on genere page_accueil
        page=SimpleDocument()
        page.append(Heading(2,'Bienvenue sur la page des diagnostiques du MRCC'))
        page.write(os.path.join(rep_web,page_accueil))


if __name__ == '__main__' :

    from wd2 import Produit,ListeProduits
    import os.path

    # clefs
    clef_fait_page_diff=1
    clef_fait_page_moy_str=1


    # on va chercher les produits disponbles
#    r=ListeProduits(rep_recherche='valid_test')
    r=ListeProduits()
    r.cherche_produits()
    r.affiche_inventaire(r.liste_produits)

    # on dresse l'inventaire des source1
    liste_source1=r.fait_inventaire(r.liste_produits,'source1')['source1']

    # on genere la page d'accueil
    rep_web='page_web'
    r.fait_page_accueil(liste_source1,rep_web,'index.html')

    # on boucle sur les source1
    for s in liste_source1 :

##         # si la source1 est un dm et qu'il y a un di correspondant, on ajoute ces champs au menu.
##         d={'source1':s}
##         if s[:2] == 'dm' :
##             if 'di'+s[3:] in liste_source1 :
##                 d={'source1':[s,di+s[3:]]}
        d={'source1':s}
        liste_reduite=r.extrait_produits(r.liste_produits,d)
        # on met les produits a jour
        for p in liste_reduite :
            # maj des repertoire et fichier htm
            p.rep_web=rep_web
            p.maj_fichier_htm()
            # maj de rep_img pour que les liens suivent
            p.rep_img=os.path.join('..',p.rep_img)

        # on genere le menu
        fichier_menu=os.path.join(rep_web,'menu_'+s+'.html')
        r.fait_page_menu(liste_reduite,crit_menu='source1',crit_tab='type',fichier=fichier_menu)

        # on genere les pages des produits
        for p in liste_reduite :
            fichier=os.path.join(rep_web,p.fichier_htm)
            if p.type in ['moy','str'] :
               if clef_fait_page_moy_str : r.fait_page_moy_str(p,liste_reduite,fichier)
            elif p.type in ['diff moy','diff str'] :
                if clef_fait_page_diff : r.fait_page_diff(p,liste_reduite,fichier)

    # fin boucle sur les source1
