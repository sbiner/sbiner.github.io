# module contenant diverses fonctions

# FONCTIONS
# fonction qui retourne une seule copie des elements d'une liste
def uniq(ma_liste):
    """
    fonction qui retourne la liste envoye en argument
    triee et sans les repetions d'arguments
    eg. [3,2,2,1] devient [1,2,3]
    """
    ma_liste.sort()
    if not ma_liste : return ma_liste
    sortie=[ma_liste[0]]
    for i in range(1,len(ma_liste)) :
        if ma_liste[i-1] != ma_liste[i] : sortie.append(ma_liste[i])
    return sortie

# fonction qui inverses les clef et valeur d'un dictionnaire
def inverse_dico(dico) :
    """
    fonction qui inverse un dictionnaire. Les clef deviennent valeur
    et vice-versa
    """
    clef_inv=dico.values()
    val_inv=dico.keys()
    dico_inv={}
    for (k,v) in zip(clef_inv,val_inv) : dico_inv[k]=v
    return dico_inv

# fonction qui classe une liste de dictionnaire par une clef du dictionnaire
def classe_liste_dict(liste,clef,ordre) :
    # adapte d'un truc de guido van rossum (sorting ...)
    for d in liste :
        if clef not in d.keys() :
            print 'erreur dans classe_liste_dict'
            print 'clef ',clef,' pas dans ',d
            return None
    nliste=map(lambda x,c=clef: (x[clef],x), liste)
#    print nliste
    nliste.sort()
    if ordre == -1 : nliste.reverse()
    nliste=map(lambda (c,x) : x, nliste)
#    print nliste
    return nliste
               
def etend_dico(d) :

    # fonction qui lit un dictionnaire avec des valeurs qui peuvent etre des listes.
    # la fonction retourne un liste de dictionnaire avec une valeur de la liste par clefs
    #
    # e.g. d={'x':[1,2]}
    #      liste=etend_dico(x)
    #      liste=[{'x':1},{'x',2}]

    # on defini la methode recursive qui va faire le boulot
    def _etend_dico(d,liste) :

        # on trouve la premiere clef dont la valeur est une liste
        liste_clefs=d.keys()
        clef=''
        for k in liste_clefs :
            if type(d[k]) is list : clef=k
            
        # si clef est nulle, on ajoute le dictionnaire a la liste
        if clef == '' :
            liste.append(d)
        # sinon execute etend_dico sur les different dico qu'on peut former avec la liste trouvee
        else :
            index=liste_clefs.index(clef)
            # on bati les dico deja traite et a traiter
            clefs_deja_traitees=liste_clefs[:index]
            clefs_a_traiter=liste_clefs[index+1:]
            dico_deja_traite={}
            dico_a_traiter={}
            for k in clefs_deja_traitees :
                dico_deja_traite[k]=d[k]
            for k in clefs_a_traiter :
                dico_a_traiter[k]=d[k]
            # on bati les dico de sortie
            for val in d[clef] :
                dico_tmp={}
                dico_tmp.update(dico_a_traiter)
                dico_tmp[clef]=val
                dico_tmp.update(dico_deja_traite)
                # on appel etend_dico sur le nouveau dictionnaire
                _etend_dico(dico_tmp,liste)



    liste_sortie=[]
    _etend_dico(d,liste_sortie)
    return liste_sortie

def rend_liste(x) :
    """
    fonction qui transforme un element en une liste d'un seul element s'il n'est pas une liste
    e.g. rend_liste([1,2])=[1,2]
         rend_liste('toto')=['toto']
    """
    if type(x) is not list :
        return [x]
    else :
        return x

##################################################
