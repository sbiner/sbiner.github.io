d={'x':[1,2],'y':['a','b']}#,'z':[2,4]}

def etend_dico(d) :

    # on trouve la premiere clef dont la valeur est une liste
    liste_clefs=d.keys()
    clef=''
    for k in liste_clefs :
        if type(d[k]) is list : clef=k

    # si clef est nulle, il n'y a plus de liste et on retourne le dictionnaire
    if clef == '' : return d
    # sinon execute etend_dico sur les different dico qu'on peut former avec la liste trouvee
    else :
        index=liste_clefs.index(clef)
        # on bati les dico deja traite et a traiter
        clefs_deja_traitees=liste_clefs[:index]
        clefs_a_traiter=liste_clefs[index+1:]
        dico_deja_traite={}
        dico_a_traiter={}
        for k in clefs_deja_traitees :
            dico_deja_traite[k]=d[k]
        for k in clefs_a_traiter :
            dico_a_traiter[k]=d[k]
        # on bati les dico de sortie
        liste_dico_sortie=[]
        for val in d[clef] :
            dico_tmp={}
            dico_tmp.update(dico_a_traiter)
            dico_tmp[clef]=val
            dico_tmp.update(dico_deja_traite)
            # on etend le nouveau dico et on l'ajoute a la liste de sortie
            liste_dico_sortie.append(etend_dico(dico_tmp))
        # on retourne la sortie
        return liste_dico_sortie

def etend_dico2(d,liste_sortie) :

    print 'entree etend_dico2'
    print 'd=',d
    print 'liste_sortie a l entree=',liste_sortie
    
    # on trouve la premiere clef dont la valeur est une liste
    liste_clefs=d.keys()
    clef=''
    for k in liste_clefs :
        if type(d[k]) is list : clef=k

    # si clef est nulle, il n'y a plus de liste et on retourne le dictionnaire
    if clef == '' :
        return d
    # sinon execute etend_dico sur les different dico qu'on peut former avec la liste trouvee
    else :
        index=liste_clefs.index(clef)
        # on bati les dico deja traite et a traiter
        clefs_deja_traitees=liste_clefs[:index]
        clefs_a_traiter=liste_clefs[index+1:]
        dico_deja_traite={}
        dico_a_traiter={}
        for k in clefs_deja_traitees :
            dico_deja_traite[k]=d[k]
        for k in clefs_a_traiter :
            dico_a_traiter[k]=d[k]
        # on bati les dico de sortie
        for val in d[clef] :
            dico_tmp={}
            dico_tmp.update(dico_a_traiter)
            dico_tmp[clef]=val
            dico_tmp.update(dico_deja_traite)
            # on etend le nouveau dico et on l'ajoute a la liste de sortie
            sortie=etend_dico2(dico_tmp,liste_sortie)
            liste_sortie.append(sortie)
    print 'sortie etend_dico2'
    print 'd=',d
    print 'liste_sortie a la sortie=',liste_sortie

d_etendu=etend_dico(d)
print d
print d_etendu
liste=[]
etend_dico2(d,liste)
print d
print liste
