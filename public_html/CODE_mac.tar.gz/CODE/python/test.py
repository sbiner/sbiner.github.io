import biner

l=[]
l.append({'nom':'toto','score':10})
l.append({'nom':'toto','score':3})

print l

biner.classe_liste_dict(l,'score')
