from  HTMLgen import *
from os.path import *
from os import system

# definition de variables
rep_base='/expl/biner/test_htmlgen'
web_base=rep_base
liste_run=['aam','aax']
montre_sortie_tidy=0

#liste des pages

pindex='index.html'
pcoin='coin.html'
pliste_run='liste_run.html'
paccueil='accueil.html'

#liste des fichiers
findex=join(rep_base,pindex)
fcoin=join(rep_base,pcoin)
fliste_run=join(rep_base,pliste_run)
faccueil=join(rep_base,paccueil)

##################################################
# validation et refonte de la page web avec tidy 

def valide_html(fichier):
    if montre_sortie_tidy :
        print "*"*50
        print "MESSAGE DE SORTIE DE TIDY POUR FICHIER ",fichier
        print "*"*50    
        commande_tidy='/rhea/biner/bin/tidy -o '+fichier+' '+fichier
        system(commande_tidy)
        print "*"*50
    else :
        commande_tidy='/rhea/biner/bin/tidy -o '+fichier+' '+fichier+'  > /dev/null 2>&1'
        system(commande_tidy) 

##################################################
# on genere la page principale

page=FramesetDocument(title="DIAG DU MRC")

frame0=Frameset(cols='150,*')
frame01=Frameset() # partie de gauche 
frame02=Frameset() # partie de droite

#frame011=Frame(src=pcoin,frameborder=0,scrolling='no')
frame012=Frame(src=pliste_run,frameborder=0,scrolling='no')
#frame01.append(frame011)
frame01.append(frame012)

frame021=Frame(src=paccueil,frameborder=0,scrolling='auto')
frame02.append(frame021) 

frame0.append(frame01)
frame0.append(frame02)

page.append(frame0)

page.write(findex)
valide_html(findex)

##################################################
# on genere la page pliste_run

page=SimpleDocument()

page.append(Href(url=web_base,text=Heading(1,'DIAG MRC'),target='_top'))
page.append(HR())
page.append(Heading(2,'liste des run'))
page.append(HR())

table=TableLite('liste des run')
for r in liste_run :
    url='menu/'+r+'.html'
    table.append(TR(TD(Href(url=url,text=r,target='affichage'))))
    
page.append(table)

page.write(fliste_run)
valide_html(fliste_run)


