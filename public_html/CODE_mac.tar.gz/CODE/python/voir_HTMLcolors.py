

from HTMLgen import *
import HTMLcolors

couleur=['GREY1',     'GREY2','GREY3','GREY4',   'GREY5',    'GREY6' , \
'GRAY1',     'GRAY2',    'GRAY3',     'GRAY4',   'GRAY5',    'GRAY6', \
'RED', 'RED1',      'RED2',     'RED3',     'RED4',     'RED5',     'RED6' , \
'BLUE', 'BLUE1',     'BLUE2',    'BLUE3',    'BLUE4',    'BLUE5',    'BLUE6' ,\
'GREEN', 'GREEN1',    'GREEN2',   'GREEN3',   'GREEN4',   'GREEN5',   'GREEN6' , \
'GREY' ,
'WHITE' ,
'BLACK' ,
'PURPLE', 
'ORANGE', 
'SKYBLUE', 
'BROWN', 
'SEAGREEN', 
'MOROON', 
'CADETBLUE', 
'AQUA', 
'YELLOW', 
'PURPLE', 
'PEACH', 
'LIME', 
'OLIVE', 
'TAN', 
'PINK', 
'COPPER'] 




p=SimpleDocument()
t=TableLite()

nb_colonne=len(couleur)/10
compteur=0
for c in couleur :
    if compteur == 0 :
        l=TR()
        l.append(TD(c))
        texte=RawText('&nbsp')
        coul=getattr(HTMLcolors,c)
        l.append(TD(texte,bgcolor=coul,width=50))
        compteur=compteur+1
    else :
        l.append(TD(c))
        texte=RawText('&nbsp')
        coul=getattr(HTMLcolors,c)
        l.append(TD(texte,bgcolor=coul,width=50))
        compteur=compteur+1
        if compteur >= 3 :
            t.append(l)
            compteur=0
p.append(t)
p.write('voir_HTMLcolors.html')
