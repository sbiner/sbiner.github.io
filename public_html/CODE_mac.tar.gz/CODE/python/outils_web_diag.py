# version orientee objet du programme permettant de generer des
# pages web a partir d'un repertoire contenant des images
#
# en construction


from biner import inverse_dico,uniq
from biner_web import *
from string import *
from HTMLgen import *
import os.path
import string

##################################################

class produit:
    """
    classe de base pour les produits disponibles pour le site web montrant la validation
    du MRCC
    """
    dico_source1={'O':'obs','M':'dm','P':'di'}
    dico_source2={'CU':'CRU','C2':'CRU2','P':'di','HP':'HOP','WM':'WM','NA':'na','W2':'WM2','LB':'Lieb','XI':'Xie'}
    dico_saison={'E':'ete','F':'automne','H':'hiver','P':'printemps'}
    dico_type_diff={'M' : 'moy' , 'R' : 'str'}
    dico_source1_inv=inverse_dico(dico_source1)
    dico_source2_inv=inverse_dico(dico_source2)
    dico_saison_inv=inverse_dico(dico_saison)
    dico_type_diff_inv=inverse_dico(dico_type_diff)
    # liste des attributs que les autres produits doivent avoir de
    # semblable a un produit donne pour etre juges semblables
    liste_attributs_a_tester=['saison','var','niv','source1','source2','type','periode_validite']

    def __init__(self) :
        self.var=''
        self.niv='surface'
        self.source1=''
        self.source2=''
        self.fichier_img=''
        self.fichier_htm=''
        self.saison=''
        self.type=''
        self.etiquette=''
        self.rep_img=''
        self.rep_htm=''
        self.unites=''
        self.periode_validite=''

    def decode_fichier_img(self) :
        """
        fonction qui decode les attribut du produit selon le nom du fichier_img
        """
        # on verifie la validite du nom du fichier est valide
        if self.valide_fichier_img() :
            # on traite les champs autre que BLT
            if self.fichier_img[0:3] == 'blt' :
                print 'cas non traite pour l\'instant'
            else :
                #
                # fichiers autres que BLT
                #
                self.var,code,niveau=split(self.fichier_img,'_')
                #on enleve l'extension
                niveau,bidon=os.path.splitext(niveau)
                #on cherche le type du fichier
                ii_moy=find(code,'MOY')
                ii_str=find(code,'STR')
                if ii_moy != -1 :
                    type='moy'
                    indice=ii_moy
                elif ii_str != -1 :
                    type='str'
                    indice=ii_str
                else :
                    type='diff'
                # selon le type on decode les autres informations
                if type == 'moy' or type == 'str' :
                    source_base=produit.dico_source1[code[0]]
                    run=code[1:indice]
                    self.source1=source_base+run
                    self.source2=''
                    self.saison=produit.dico_saison[code[-1]]
                    self.type=type
                else :
                    source_base=produit.dico_source1[code[0]]
                    run=code[1:4]
                    self.source1=source_base+run
                    source2=produit.dico_source2[code[4:-2]]
                    if source2 == 'di' : source2=source2+run
                    self.source2=source2
                    type_diff=produit.dico_type_diff[code[-2]]
                    self.type='diff '+type_diff
                    self.saison=produit.dico_saison[code[-1]]

                # on decode le niveau
                self.niv=niveau[:-2]
                # on decode la periode de validite
                rep=self.rep_img
                for f in os.listdir(rep) :
                    if source_base in ['obs','dm'] and f[:3] == '.DM' : self.periode_validite=f[4:]
                    elif source_base in ['di'] and f[:3] == '.DI' : self.periode_validite=f[4:]
                # on s'assure qu'un periode de validite est trouvee
                if self.periode_validite == '' :
                    print 'PROBLEME'
                    print 'il manque les fichier .DI_* et .DM_* dans ',rep
                    raise PeriodeValiditeManquante
        else :
            print self.fichier_img+" non valide, fichier ignore"
            

    def fichier_img_est_present(self) :
        """
        fonction qui retourne 1 si le fichier_img correspondant a un produit
        est present et 0 si ce n'est pas le cas
        """
        bidon=self.copy()
        f=os.path.join(bidon.rep_img,bidon_fichier_img)
        if os.path.exists(f) :
            return 1
        else :
            return 0


    def encode_fichier_img(self) :
        """
        fonction qui trouve le nom du fichier_img selon les attributs du produit 
        """
        # on trouve le code pour la source1
        if self.source1[:2] == 'dm' : code_source1='M'+self.source1[2:]
        if self.source1[:2] == 'di' : code_source1='P'+self.source1[2:]
        if self.source1[:3] == 'obs' : code_source1='O'+self.source1[3:]
        #traitement selon le type
        if self.type == 'moy' or self.type == 'str' :
            # code_type='MOY' ou 'STR'
            code_type=string.upper(self.type)
            code_source2=''
        elif self.type == 'diff moy' or self.type == 'diff str' :
            # code_type = 'M' ou 'S'
            code_type=string.upper(self.type[-3])
            # on trouve le code pour source2 : P, CU, C2, ...
            clef_source2=self.source2
            if clef_source2[:2] == 'di'  :
                # source 2 est le pilote
                clef_source2=clef_source2[:2]
            code_source2=produit.dico_source2_inv[clef_source2]
        # on trouve le code de la saison
        code_saison=produit.dico_saison_inv[self.saison]
        # on batit le nom du fichier
        self.fichier_img=self.var+'_'+code_source1+code_source2+code_type+code_saison+'.gif'


    def valide_fichier_img(self) :
        """
        fonction qui s'assure qu'un nom de fichier_img est valide
        """
        f=self.fichier_img
        garde=1
        # on verifie que f ne debute pas par un "."
        if f[0] == '.' : garde=0
        # on verifie que l'extenstion et .gif
        if os.path.splitext(f)[1] not in ['.gif'] : garde=0
        # on verifie que f ne debute pas par 'blt'
        if f[0:3] in ['blt','BLT'] : garde=0
        # on retourne garde
        return garde

    def affiche(self) :
        """
        fonction qui affiche tous les attributs du produit
        """
        print "\n"+'-'*50
        print 'var=',self.var
        print 'niv=',self.niv
        print 'source1=',self.source1
        print 'source2=',self.source2
        print 'fichier_img=',self.fichier_img
        print 'fichier_htm=',self.fichier_htm
        print 'rep_img=',self.rep_img
        print 'rep_htm=',self.rep_htm
        print 'saison=',self.saison
        print 'type=',self.type
        print 'etiquette=',self.etiquette
        print "\n"+'-'*50

    def trouve_autres_produits(self,liste_prod,clef) :
        """
        fonction qui pour un produit va chercher dans une liste de produit
        ceux qui sont identique sauf pour l'argument clef. La verification est
        faite sur la liste produit.liste_attributs_a_tester.

        e.g. pour aller chercher les autres saison d'un produit p taper :
        p.trouve_autres_produits(liste_prod,'saison')

        """
        if clef not in produit.liste_attributs_a_tester :
            print 'clef \"'+clef+'\" invalide dans trouves_autres'
            return []
        
        liste=[]
        for p in liste_prod :
            garde=1
            # on boucle sur tous les attributs a tester
            for a in produit.liste_attributs_a_tester :
                attr_self=getattr(self,a)
                attr_p=getattr(p,a)
                if a != clef and attr_self != attr_p :
                    # un attribut autre que la clef est differents, on
                    # ne garde pas le produit
                    garde=0
                elif a == clef and attr_self == attr_p :
                    # le champs est identique
                    garde=0
            if garde : liste.append(getattr(p,clef))
        return liste

    def extrait_produits(self,liste_entree,dict_recherche) :
        """

        fonction qui cherche dans liste_entree les produits
        correspondant a dict_recherche. Les produits trouves sont
        retournes en sortie

        dict_recherche contient des clefs et des valeurs

        e.g. pour chercher les produit de type='aaa' et de saison='ete'

        dict_recherche={'type':'aaa','saison':'ete'}
        liste_sortie=extrait_produits(liste_entree,dict_recherche)

        ou

        liste_sortie=extrait_produits(liste_entree,{'type':'aaa','saison':'ete'})
        
        """
        liste_sortie=[]
        for p in liste_entree :
            garde=1
            for c in dict_recherche.keys() :
                if hasattr(p,c) :
                    if getattr(p,c) in dict_recherche[c] :
                        garde=1
                    else :
                        garde=0
                        break
                else :
                    garde=0
                    break
            if garde == 1 : liste_sortie.append(p)
        
        return liste_sortie

##################################################

class repertoire_validation :
    """
    classe de base pour traiter les repertoires contenant des images pour la validation du MRCC
    """
    from outils_web_diag import produit
    rep='.'
    liste_produits=[]

    def __init__(self, *arg, **kw) :
        for name, value in kw.items() :
            setattr(self,name,value)

    def fait_inventaire(self) :
        import os
        import os.path
        # on fait la liste de repertoires
        liste_rep=[]
        for d in os.listdir(self.rep) :
            if os.path.isdir(d) : liste_rep.append(d)
        liste_rep.append(self.rep)
        # on boucle sur les repertoire et on dresse une liste des produits disponibles.
        liste_produits=[]
        for rep in liste_rep :
            print '*****'
            print 'on cherche dans le repertoire ',rep
            print '*****'
            # boucle sur les fichiers du repertoire
            liste_fichiers=os.listdir(rep)
            for f in liste_fichiers :
                bidon=produit()
                bidon.rep_img=rep
                bidon.fichier_img=f
                # si le nom de fichier semble valide, on le decode et
                # on ajoute le produit a la liste
                if bidon.valide_fichier_img() :
                    bidon.decode_fichier_img()
                    print 'fichier ',f,' valide'
                    # tout est beau, on ajoute le produit a la liste
                    liste_produits.append(bidon)
        # on s'assure d'eviter les repetitions
        self.liste_produits=uniq(liste_produits)

    def affiche_inventaire(self,*args,**kw) :
        # si des clefs sont passe en argument on restreint l'inventaire a ces clefs
        if len(args) > 0 :
            liste_clefs=args
        else :     
            # on affiche tout ce qu'il y a dans liste_produits
            liste_clefs=['var','niv','source1','source2','saison','type','periode_validite']
        # si la clef sortie=liste est passe en argument, on passe les liste en sortie
        sortie_liste=0
        for nom,val in kw.items() :
            if nom == 'sortie' and val == 'liste' : sortie_liste=1

        liste={}
        for c in liste_clefs :
            liste[c]=[]
        for p in self.liste_produits :
            for c in liste_clefs :
                l=liste[c]
                l.append(getattr(p,c))
                liste[c]=uniq(l)
        print '***** INVENTAIRE *****'
        for c in liste_clefs :
            print 'liste de ',c,'=',liste[c]
        print '**********************'
        if sortie_liste : return liste

##################################################

class page_web_diag :
    import HTMLcolors

    page_base=SimpleDocument(bgcolor=HTMLcolors.CADETBLUE)
    
    def fait_page_menu(self,liste_produits,**kw) :
        
        """
        methode qui fait une page web a partir d'une liste de produit disponible
        
        """
        # valeur par defaut
        crit_menu='source1'    # critere du produit commun a tous les produits du menu
        crit_tab='type'        # critere commun aux produits presents dans le meme tableau
        fichier='menu.html'  # nom du fichier de sortie
        
        # valeurs passees en argument
        for n,val in kw.items() :
            if n == 'crit_menu' : crit_menu=val
            if n == 'type' : crit_tab=val
            if n == 'fichier' : fichier=val
            
        # generation de la page web

        # on met l'entete
        entete=Entete()
        
        # on ajoute le titre
        
        val_crit_menu=getattr(liste_produits[0],crit_menu)
        texte=Heading(2,'Menu pour la simulation dont '+crit_menu+'=',val_crit_menu,align='center')
        entete.append(texte)

        # on dresse la liste des tableaux qui vont etre affiches
        rep_bidon=repertoire_validation()
        rep_bidon.liste_produits=liste_produits
        liste_tableaux=rep_bidon.affiche_inventaire(crit_tab,sortie='liste')
        for t in liste_tableaux[crit_tab] :
            print t


        page=self.page_base
        page.append(entete)
        page.write(fichier)
        

if __name__ == '__main__' :

    from outils_web_diag import produit,repertoire_validation

    r=repertoire_validation(rep='valid_test')
    r.fait_inventaire()
    r.affiche_inventaire()
    r.affiche_inventaire('var')
    r.affiche_inventaire('source1','source2')
    d={'source1':'dmAAB'}
    p=produit()
    liste_prod=p.extrait_produits(r.liste_produits,d)
    print 'dictionnaire_recherche=',d
    for p in liste_prod :
        print p.fichier_img
    p=page_web_diag()
    p.fait_page_menu(liste_prod)
    
