from Tkinter import *

root=Tk()
root.title('teste image')
pic=PhotoImage(file='/expl/biner/test_mrc3.7/schema_flux.gif')
item=Canvas(root,height=750,width=740)
item.create_image(0,0,image=pic,anchor=NW)
item.create_rectangle(0,0,100,100,fill='red')
item.pack()

root.mainloop()
