from time import *
import string

fichier_temps='essai_date'

file=open(fichier_temps,'r')
while 1:
    ligne=file.readline()
    if not ligne : break
    print ligne
print 'lecture finie'    
file.close()

for ligne in open(fichier_temps,'r').readlines() : print ligne


# on separe la ligne

print ligne
ligne=string.split(ligne)
print ligne                  

format_temps='%Y/%m/%d/%H:%M'

temps1=strptime(ligne[1],format_temps)
temps2=strptime(ligne[2],format_temps)
diff_temps=mktime(temps2)-mktime(temps1)

diff_j=int(diff_temps/86400)
diff_h=int(diff_temps/3600.)-diff_j*24
diff_m=int(diff_temps/60.)-diff_h*60-diff_j*24*60


print 'temps1=',temps1
print 'temps2=',temps2
print 'diff_temps=',diff_temps
print 'diff_j,h,m=',diff_j,diff_h,diff_m
