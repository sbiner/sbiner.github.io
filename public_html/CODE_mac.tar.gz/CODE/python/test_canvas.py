from Tkinter import *

root=Tk()
base=Canvas(root,width=50,height=50)
base.create_rectangle(0,0,50,25,fill='red')
base.create_rectangle(0,25,50,50,fill='blue')

base.pack()
root.mainloop()
