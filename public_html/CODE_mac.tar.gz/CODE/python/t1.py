
f=open('toto','w')
