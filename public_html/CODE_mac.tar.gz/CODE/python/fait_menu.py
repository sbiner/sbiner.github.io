# programme python qui genere lit un repertoire contenant des images
# dont le nom a un format particulier et genere une repertoire
# contenant des pages web avec un menu permettant d'acceder des pages
# web ou on peut voir les differentes images


from os import *
from os import *
from string import *
from HTMLgen import *


##################################################
# FONCTIONS
def uniq(ma_liste):
    ma_liste.sort()
    if not ma_liste : return ma_liste
    sortie=[ma_liste[0]]
    for i in range(1,len(ma_liste)) :
        if ma_liste[i-1] != ma_liste[i] : sortie.append(ma_liste[i])
    return sortie

#####
def decode(f) :
    variable,code=split(f,'_')
    code,bidon=split(code,'.')
    source_base={ 'M':'dm','P':'di', 'O':'obs'}[code[0]]
###    indice=find(code,'MOY')
    indice=find(code,CLEF_ENCODE_DECODE)
    source_detail=code[1:indice]
    source=source_base+source_detail
    saison={'E':'ete','F':'automne','H':'hiver','P':'printemps'}[code[-1]]
    return variable,source,saison

#####
def decode2(f) :
    # on decode les fichiers du type VV_SO1SO2TYPE.[gif,jpg]
    variable,code=split(f,'_')
    code,bidon=split(code,'.')
    # on cherche le type du fichier
    ii=find(code,'MOY')
    if ii != -1 :
        type='moy'
    else :
        ii=find(code,'STR')
        if ii != -1 :
            type='str'
        else :
            type='diff'
    # selon le type on cherche les info du fichies de maniere differente
    if type == 'moy' or type == 'str' :
        source_base={ 'M':'dm','P':'di', 'O':'obs'}[code[0]]
        source_detail=code[1:ii]
        source=source_base+source_detail
        saison={'E':'ete','F':'automne','H':'hiver','P':'printemps'}[code[-1]]
    else :
        source_base={ 'M':'dm','P':'di'}[code[0]]
        source1=code[1:4]
        source2={'C2' : 'CRU2' , 'CU' : 'CRU' } [code[4:-2]]
        source_comparaison={'M' : 'moy' , 'R' : 'str'}[code[-2]]
        source=source_comparaison+' '+source_base+source1+'_vs_'+source2
        saison={'E':'ete','F':'automne','H':'hiver','P':'printemps'}[code[-1]]
    return type,variable,source,saison

#####
def encode(variable,source,saison) :
    if source[0:2] == 'dm'  : code_so='M'+source[2:]
    if source[0:2] == 'di'  : code_so='P'+source[2:]
    if source[0:3] == 'obs'  : code_so='O'+source[3:]
    code_sa={'ete':'E','automne':'F','hiver':'H','printemps':'P'}[saison]
    return variable+'_'+code_so+CLEF_ENCODE_DECODE+code_sa

#####
def encode2(type,variable,source,saison) :
    if type == 'moy' or type == 'str' :
        if source[0:2] == 'dm'  : code_so='M'+source[2:]
        if source[0:2] == 'di'  : code_so='P'+source[2:]
        if source[0:3] == 'obs' : code_so='O'+source[3:]
        code_type={'moy' : 'MOY' , 'str' : 'STR'}[type]
        code_so=code_so+code_type
    else :
        #on rebatit le nom du fichier
        code_comparaison={'moy' : 'M' , 'str' : 'R' } [source[0:3]]
        code_source_base={'dm' : 'M' , 'di' : 'P'} [source[4:6]]
        bidon1,bidon2=split(source,'_vs_')
        code_source1=bidon1[6:]
        code_source2={'CRU2' : 'C2' , 'CRU' : 'CU'} [bidon2]
        code_so=code_source_base+code_source1+code_source2+code_comparaison
        
    code_sa={'ete':'E','automne':'F','hiver':'H','printemps':'P'}[saison]

    return variable+'_'+code_so+code_sa

##### 
def decode_source_diff(source_diff) :
    source=source_diff
    code_comparaison=source[0:3]
    code_source_base=source[4:6]
    bidon1,bidon2=split(source,'_vs_')
    code_source1=bidon1[6:]
    code_source2={'CRU2' : 'obsC2', 'CRU' : 'obsC' } [bidon2]

    source_mrc=code_source_base+code_source1
    source_obs=code_source2

    return source_mrc,source_obs,code_comparaison
    

#####
def fait_liste_var(liste_f):
    liste_var=[]
    for f in liste_f :
        variable,source,saison=decode(f)
        liste_var.append(variable)
    liste_var=uniq(liste_var)
    return liste_var

#####
def fait_liste_var2(type,liste_f) :
    liste_var=[]
    for f in liste_f :
        type,variable,source,saison=decode2(f)
        liste_var.append(variable)
    liste_var=uniq(liste_var)
    return liste_var

#####
def fait_liste_sources2(type,liste_f) :
    liste_source=[]
    for f in liste_f :
        type,variable,source,saison=decode2(f)
        liste_source.append(source)
    liste_source=uniq(liste_source)
    return liste_source

#####
def fait_liste_saisons2(type,liste_f) :
    liste_saisons=[]
    for f in liste_f :
        type,variable,source,saison=decode2(f)
        liste_saisons.append(saison)
    liste_saisons=uniq(liste_saisons)
    return liste_saisons

#####
def fait_liste_sources(liste_f):
    liste_source=[]
    for f in liste_f :
        variable,source,saison=decode(f,)
        liste_source.append(source)
    liste_source=uniq(liste_source)
    return liste_source

#####
def fait_liste_saisons(liste_f) :
    liste_saisons=[]
    for f in liste_f :
        variable,source,saison=decode(f)
        liste_saisons.append(saison)
    liste_saisons=uniq(liste_saisons)
    return liste_saisons

#####
def fait_menu(liste_f,liste_v,liste_so,liste_sa):
    menu={}
    # on met la valeur de menu a 0 par defaut
    for v in liste_v :
        for so in liste_so :
            for sa in liste_sa :
                menu[(v,so,sa)]=0
    # on boucle sur les fichiers pour mettre le menu a jour
    for f in liste_f :
        v,so,sa=decode(f)
        menu[(v,so,sa)]=1
    # on retourne le menu
    return menu

#####
def fait_menu2(type,liste_f,liste_v,liste_so,liste_sa):
    menu={}
    #on met la valeur de menu a 0 par defaut
    for v in liste_v :
        for so in liste_so :
            for sa in liste_sa :
                menu[(v,so,sa)]=0
    # on boucle sur les fichiers pour mettre le menu a jour
    for f in liste_f :
        t,v,so,sa=decode2(f)
        menu[(v,so,sa)]=1
    # on retourne le menu
    return menu
    
#####
def fait_tableau_menu(titre,menu,liste_v,liste_so,liste_sa) :
    table=TableLite(titre,border=1,Class='menu')

    # on genere le titre des colonnes du tableau
    ligne=TR()
    ligne.append(TH('variable',Class='menu'))
    ligne.append(TH('source',Class='menu'))
    for sa in liste_sa :
        ligne.append(TH(sa,width=100,Class='menu'))
    table.append(ligne)

    # on remplie le tableau selon ce qui est disponible
    for v in liste_v :
        for so in liste_so :
            ligne=TR()
            ligne.append(TD(v))
            ligne.append(TD(so))
            nb_saison=0
            for sa in liste_sa :
                if menu[(v,so,sa)] == 1:
                    nb_saison=+1
                    lien=encode(v,so,sa)
                    lien=lien+'.html'
                    ligne.append(TD(Href(url=lien,text='X',target='_self'),align='center'))
                else :
                    ligne.append(TD('NA',color='red'))
            if nb_saison !=0 :
                # on ecrit la ligne dans le fichier
                table.append(ligne)
    # on retourne le tableau
    return table

#####
def fait_tableau_menu2(titre,type,menu,liste_v,liste_so,liste_sa) :
    table=TableLite(titre,border=1,Class='menu')

    # on genere le titre des colonnes du tableau
    ligne=TR()
    ligne.append(TH('variable',Class='menu'))
    ligne.append(TH('source',Class='menu'))
    for sa in liste_sa :
        ligne.append(TH(sa,width=100,Class='menu'))
    table.append(ligne)

    # on remplie le tableau selon ce qui est disponible
    for v in liste_v :
        for so in liste_so :
            ligne=TR()
            ligne.append(TD(v))
            ligne.append(TD(so))
            nb_saison=0
            for sa in liste_sa :
                if menu[(v,so,sa)] == 1:
                    nb_saison=+1
                    lien=encode2(type,v,so,sa)
                    if type == 'diff' : lien='comp_'+lien
                    lien=lien+'.html'
                    ligne.append(TD(Href(url=lien,text='X',target='_self'),align='center'))
                else :
                    ligne.append(TD('NA',color=red))
            if nb_saison !=0 :
                # on ecrit la ligne dans le fichier
                table.append(ligne)
    # on retourne le tableau
    return table

#####
def genere_pages(menu,liste_v,liste_so,liste_sa) :
    # genere les pages de moy et str
    for v in liste_v :
        for so in liste_so :
            for sa in liste_sa :
                if menu[(v,so,sa)] == 1:
                    # on dresse la liste des parametres (variables, sources et saison) disponibles
                    # pour lorsque les deux autres parametre sont les memes
                    autre_variables_dispo=[]
                    autre_saisons_dispo=[]
                    autre_sources_dispo=[]
                    for vv in liste_v :
                        if menu[(vv,so,sa)] == 1 and vv != v : autre_variables_dispo.append(vv)
                    for ssa in liste_sa :
                        if menu[(v,so,ssa)] == 1 and ssa != sa : autre_saisons_dispo.append(ssa)
                    for sso in liste_so :
                        if menu[(v,sso,sa)] == 1 and sso != so : autre_sources_dispo.append(sso)
                    #on genere la page pour cette case du menu
                    image=encode(v,so,sa)+'.gif'
                    fcase=encode(v,so,sa)+'.html'
                    fcase=os.path.join(rep_web,fcase)
                    page_case=SimpleDocument('menu.rc')
                    titre=Heading(3,'variable '+v+' '+CLEF_ENCODE_DECODE+' '+sa+' de '+so)
                    page_case.append(titre)
                    ###page_case.append(Heading(2,fcase))
                    ###page_case.append(HR())
                    page_case.append(Image(os.path.join('../',rep,image)))
                    page_case.append(HR())
                    #on offre un menu des autres variables disponibles si c'est le cas
                    if len(autre_variables_dispo) >= 1 :
                        texte=Paragraph('autre variables disponibles : ')
                        for vv in autre_variables_dispo :
                            lien=encode(vv,so,sa)
                            lien=lien+'.html'
                            texte.append(Href(url=lien,text=vv))
                            texte.append(' ')
                        page_case.append(texte)
                    #on offre un menu des autres saison disponibles si c'est le cas
                    if len(autre_saisons_dispo) >=1 :
                        texte=Paragraph('autre saison disponibles : ')
                        for ssa in autre_saisons_dispo :
                            lien=encode(v,so,ssa)
                            lien=lien+'.html'
                            texte.append(Href(url=lien,text=ssa))
                            texte.append(' ')
                        page_case.append(texte)
                    #on offre un menu des autres sources disponibles si c'est le cas
                    if len(autre_sources_dispo) >=1 :
                        texte=Paragraph('autre sources disponibles : ')
                        for sso in autre_sources_dispo :
                            lien=encode(v,sso,sa)
                            lien=lien+'.html'
                            texte.append(Href(url=lien,text=sso))
                            texte.append(' ')
                        page_case.append(texte)
                    # on offre un lien vers le menu principal
                    lien='menu_'+run+'.html'
                    page_case.append(Href(url=lien,text='menu principal pour run '+run))
                    page_case.write(fcase)

#####
def genere_pages2(type,menu,liste_v,liste_so,liste_sa) :
    for v in liste_v :
        for so in liste_so :
            for sa in liste_sa :
                if menu[(v,so,sa)] == 1:
                    # on dresse la liste des parametres (variables, sources et saison) disponibles
                    #  lorsque les deux autres parametre sont les memes
                    autre_variables_dispo=[]
                    autre_saisons_dispo=[]
                    autre_sources_dispo=[]
                    for vv in liste_v :
                        if menu[(vv,so,sa)] == 1 and vv != v : autre_variables_dispo.append(vv)
                    for ssa in liste_sa :
                        if menu[(v,so,ssa)] == 1 and ssa != sa : autre_saisons_dispo.append(ssa)
                    for sso in liste_so :
                        if menu[(v,sso,sa)] == 1 and sso != so : autre_sources_dispo.append(sso)
                    #on genere la page pour cette case du menu
                    page_case=SimpleDocument('menu.rc')
                    # on met le titre et un lien vers le menu principal
                    tableau=TableLite()
                    ligne=TR()
                    if type == 'moy' or 'type' == 'str' :
                        titre=Heading(3,'variable '+v+' '+type+' '+sa+' de '+so)
                    else :
                        titre=Heading(3,'diff '+v+' '+so)
                    ligne.append(TD(titre))
                    lien='menu_'+run+'.html'
                    lien=Href(url=lien,text='retour au menu principal pour '+run)
                    ligne.append(TD(lien))
                    tableau.append(ligne)
                    page_case.append(tableau)
                    
                    # on insere l'image
                    page_case.append(HR())
                    image=encode2(type,v,so,sa)+'.gif'
                    fimage=os.path.join(rep_base,rep,image)
                    page_case.append(Image(fimage))
                    page_case.append(HR())

                    # on insere le tableau contenant les autres variables/saisons/sources
                    # disponible
                    tableau_autres=TableLite('autres pages semblables disponibles',cellspacinging=10,border=1)
                    ligne1=TR()
                    ligne2=TR()
                    if len(autre_variables_dispo) >= 1 :
                        ligne1.append(TH('autre variables'))
                        case=TD()
                        for vv in autre_variables_dispo :
                            lien=encode2(type,vv,so,sa)
                            lien=lien+'.html'
                            case.append(Href(url=lien,text=vv))
                            case.append(' ')
                        ligne2.append(case)
                    if len(autre_saisons_dispo) >=1 :
                        ligne1.append(TH('autre saisons'))
                        case=TD()
                        for ssa in autre_saisons_dispo :
                            lien=encode2(type,v,so,ssa)
                            lien=lien+'.html'
                            case.append(Href(url=lien,text=ssa))
                            case.append(' ')
                        ligne2.append(case)
                    if len(autre_sources_dispo) >=1 :
                        ligne1.append(TH('autre sources'))
                        case=TD()
                        for sso in autre_sources_dispo :
                            lien=encode2(type,v,sso,sa)
                            lien=lien+'.html'
                            case.append(Href(url=lien,text=sso))
                            case.append(' ')
                        ligne2.append(case)
                    tableau_autres.append(ligne1)
                    tableau_autres.append(ligne2)
                    page_case.append(tableau_autres)
                    # on ecrit le fichier avec la page
                    fcase=encode2(type,v,so,sa)+'.html'
                    fcase=os.path.join(rep_web,fcase)
                    page_case.write(fcase)

#####
def genere_pages_diff_comp(menu,liste_v,liste_so,liste_sa) :
    # genere les pages avec les diffs et les champs du modele et des obs
    for v in liste_v :
        for so in liste_so :
            for sa in liste_sa :
                if menu[(v,so,sa)] == 1:
                    # on dresse la liste des parametres (variables, sources et saison) disponibles
                    #  lorsque les deux autres parametre sont les memes
                    autre_variables_dispo=[]
                    autre_saisons_dispo=[]
                    autre_sources_dispo=[]
                    for vv in liste_v :
                        if menu[(vv,so,sa)] == 1 and vv != v : autre_variables_dispo.append(vv)
                    for ssa in liste_sa :
                        if menu[(v,so,ssa)] == 1 and ssa != sa : autre_saisons_dispo.append(ssa)
                    for sso in liste_so :
                        if menu[(v,sso,sa)] == 1 and sso != so : autre_sources_dispo.append(sso)
                    #on genere la page pour cette case du menu
                    page=SimpleDocument('menu.rc')
                    # on met le titre et un lien vers le menu principal
                    tableau=TableLite()
                    ligne=TR()
                    so_modele,so_obs,so_comp=decode_source_diff(so)
                    titre=Heading(3,'variable '+v+' '+so_comp+' '+sa+' '+so_modele+' vs '+so_obs)
                    ligne.append(TD(titre))
                    lien='menu_'+run+'.html'
                    lien=Href(url=lien,text='retour au menu principal pour '+run)
                    ligne.append(TD(lien))
                    tableau.append(ligne)
                    page.append(tableau)
                    page.append(HR())

                    largeur_image=499
                                        
                    # on fait la case avec le champ du modele
                    so_modele,so_obs,so_comp=decode_source_diff(so)
                    code=encode2(so_comp,v,so_modele,sa)
                    fimage=os.path.join(rep_base,rep,code+'.gif')
                    lien=code+'.html'
                    lien=Href(url=lien)
                    lien.append(Image(fimage,width=largeur_image))
                    case_modele=TD(align='center')
                    if os.path.isfile(fimage) :
                        case_modele.append(lien)
                        case_modele.append(P())
                        case_modele.append(so_modele)

                    # on fait la case avec le champ des obs
                    so_modele,so_obs,so_comp=decode_source_diff(so)
                    print "so_obs=",so_obs
                    code_obs={'C' : 'CU' , 'C2' : 'C2'} [so_obs[3:]]
                    so_obs='obs'+code_obs
                    print "so_comp=",so_comp
                    print "code=",encode2(so_comp,v,so_obs,sa)
                    code=encode2(so_comp,v,so_obs,sa)
                    fimage=os.path.join(rep_base,rep,code+'.gif')
                    lien=code+'.html'
                    lien=Href(url=lien)
                    lien.append(Image(fimage,width=largeur_image))
                    case_obs=TD(align='center')
                    if os.path.isfile(fimage) :
                        case_obs.append(lien)
                        case_obs.append(P())
                        case_obs.append(so_obs)

                    # on fait la case avec le champ de la diff
                    code=encode2('diff',v,so,sa)
                    fimage=os.path.join(rep_base,rep,code+'.gif')
                    lien=code+'.html'
                    lien=Href(url=lien)
                    lien.append(Image(fimage,width=largeur_image))
                    case_diff=TD(align='center')
                    if os.path.isfile(fimage) :
                        case_diff.append(lien)
                        case_diff.append(P())
                        case_diff.append(so)

                    # on fait une case contenant les autres variables/saisons/sources disponibles
                    tableau_autres=TableLite('autres pages semblables disponibles',cellspacinging=10,border=1)
                    ligne1=TR()
                    ligne2=TR()
                    if len(autre_variables_dispo) >= 1 :
                        ligne1.append(TH('autre variables'))
                        case=TD()
                        for vv in autre_variables_dispo :
                            lien=encode2(type,vv,so,sa)
                            lien='comp_'+lien+'.html'
                            case.append(Href(url=lien,text=vv))
                            case.append(' ')
                        ligne2.append(case)
                    if len(autre_saisons_dispo) >=1 :
                        ligne1.append(TH('autre saisons'))
                        case=TD()
                        for ssa in autre_saisons_dispo :
                            lien=encode2(type,v,so,ssa)
                            lien='comp_'+lien+'.html'
                            case.append(Href(url=lien,text=ssa))
                            case.append(' ')
                        ligne2.append(case)
                    if len(autre_sources_dispo) >=1 :
                        ligne1.append(TH('autre sources'))
                        case=TD()
                        for sso in autre_sources_dispo :
                            lien=encode2(type,v,sso,sa)
                            lien='comp_'+lien+'.html'
                            case.append(Href(url=lien,text=sso))
                            case.append(' ')
                        ligne2.append(case)
                    tableau_autres.append(ligne1)
                    tableau_autres.append(ligne2)
                    case_autres=TD()
                    case_autres.append(tableau_autres)

                    # on insere le tableau contenant les images et les autres variables/saisons/sources disponibles
                    table=TableLite(width='100%')
                    ligne=TR()
                    ligne.append(case_modele)
                    ligne.append(case_diff)
                    table.append(ligne)
                    ligne=TR()
                    ligne.append(case_obs)
                    ligne.append(case_autres)
                    table.append(ligne)
                    page.append(table)
                    page.append(HR())

                    # on ecrit le fichier avec la page
                    fcase=encode2('diff',v,so,sa)+'.html'
                    fcase=os.path.join(rep_web,'comp_'+fcase)
                    page.write(fcase)


##################################################
# programme qui fait le menu des pages web disponibles selon les
# fichiers qui se trouvent dans une liste de repertoires

rep_base='/expl/biner/test_htmlgen'
web_base=rep_base
run='aao'
rep='valid_aao_vs_cru'
rep_web=rep+'_web'

# on genere le repertoire rep_web si necessaire
if not os.path.exists(rep_web) :
    print 'on genere ',rep_web
    os.mkdir(rep_web)

# on dresse la liste des fichiers disponible dans rep
liste_fichiers=listdir(rep)
# on enleve de la liste les fichiers ne respectant pas le format VVVV_XXXXXX.gif

nouv_liste_fichiers=[]
for f in liste_fichiers :
    garde=1
    # on verifie que le nom du fichier ne commence par par .
    if f[0] == '.' : garde=0
    # on verifie qu'il n'y a qu'un '_'
    indice1=find(f,'_')
    indice2=rfind(f,'_')
    if indice1 != indice2 and indice1 == -1 : garde=0
    # si garde != 0 on ajoute f a la nouvelle liste de fichier
    if garde != 0 : nouv_liste_fichiers.append(f)
# on met liste_fichiers a jour
liste_fichiers=nouv_liste_fichiers


# recherche des fichiers du menu de moyenne inter-annuelles

liste_fichiers_moy=[]
for f in liste_fichiers :
    indice=find(f,'MOY')
    if indice != -1 :
        liste_fichiers_moy.append(f)

# on fait le menu pour MOY

CLEF_ENCODE_DECODE='MOY'
liste_variables_moy=fait_liste_var(liste_fichiers_moy)
liste_sources_moy=fait_liste_sources(liste_fichiers_moy)
liste_saisons_moy=fait_liste_saisons(liste_fichiers_moy)
menu_moy=fait_menu(liste_fichiers_moy,liste_variables_moy,liste_sources_moy,liste_saisons_moy)

# recherches des fichiers du menu pour ecart-type inter-annuels
liste_fichiers_str=[]
for f in liste_fichiers :
    indice=find(f,'STR')
    if indice != -1 :
        liste_fichiers_str.append(f)

# on fait le menu pour STR

CLEF_ENCODE_DECODE='STR'
liste_variables_str=fait_liste_var(liste_fichiers_str)
liste_sources_str=fait_liste_sources(liste_fichiers_str)
liste_saisons_str=fait_liste_saisons(liste_fichiers_str)
menu_str=fait_menu(liste_fichiers_str,liste_variables_str,liste_sources_str,liste_saisons_str)

# recherche des fichiers contenant des diffs.
# la recherche se fait en cherchant un fichier dont la partie sans
# variable debute par un 'M' et ne contenant pas MOY ou STR

liste_fichiers_diff=[]
for f in liste_fichiers :
    indice=find(f,'_')
    if indice != -1 : 
        bidon,code=split(f,'_')
        if code[0] == 'M' :
            indice1=find(code,'STR')
            indice2=find(code,'MOY')
            if indice1 == -1 and indice2 == -1 :
                liste_fichiers_diff.append(f)


liste_variables_diff=fait_liste_var2('DIFF',liste_fichiers_diff)
liste_sources_diff=fait_liste_sources2('DIFF',liste_fichiers_diff)
liste_saisons_diff=fait_liste_saisons2('DIFF',liste_fichiers_diff)
menu_diff=fait_menu2('DIFF',liste_fichiers_diff,liste_variables_diff,liste_sources_diff,liste_saisons_diff)

#print "liste_fichiers_diff=",liste_fichiers_diff
#print "liste_var",liste_variables_diff
#print "liste_sources=",liste_sources_diff
#print "liste_saisons=",liste_saisons_diff
#print "menu_diff=",menu_diff

##################################################
# on fait les page web

bidon='menu_'+run+'.html'
fmenu=os.path.join(rep_web,bidon)

#print "bidon=",bidon
#print "rep_web=",rep_web
#print "fmenu=",fmenu

# on ouvre la page principale
page_principale=SimpleDocument('menu.rc')

page_principale.append(Heading(2,'menu pour run '+run))
page_principale.append(HR())

# on insere le tableau des moyennes saisonnieres et les pages associees
CLEF_ENCODE_DECODE='MOY'
tableau_moy=fait_tableau_menu('moyennes saisonnieres',menu_moy,liste_variables_moy,liste_sources_moy,liste_saisons_moy)
page_principale.append(tableau_moy)
page_principale.append(HR())
genere_pages2('moy',menu_moy,liste_variables_moy,liste_sources_moy,liste_saisons_moy)


# on insere le tableau des ecart-types inter-annuels et les pages associees
CLEF_ENCODE_DECODE='STR'
tableau_str=fait_tableau_menu('ecart-types interannuels',menu_str,liste_variables_str,liste_sources_str,liste_saisons_str)
page_principale.append(tableau_str)
page_principale.append(HR())
genere_pages2('str',menu_str,liste_variables_str,liste_sources_str,liste_saisons_str)

# on insere le tableau avec les diffs et les pages associees
tableau_diff=fait_tableau_menu2('differences','diff',menu_diff,liste_variables_diff,liste_sources_diff,liste_saisons_diff)
page_principale.append(tableau_diff)
page_principale.append(HR())
genere_pages2('diff',menu_diff,liste_variables_diff,liste_sources_diff,liste_saisons_diff)
genere_pages_diff_comp(menu_diff,liste_variables_diff,liste_sources_diff,liste_saisons_diff)

page_principale.write(fmenu)
            
            

