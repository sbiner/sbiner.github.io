from Tkinter import *
import string , os
import tkFont

##################################################
# variables

# image en background
fond='/expl/biner/test_mrc3.7/FLUX/schema_flux.gif'

# dimension de la figure schema_flux.gif
ni_fig=720
nj_fig=540
# dimension du canvas
ni_max=720
nj_max=800
# liste de couleur
liste_couleurs=['blue','green','red','orange','magenta','cyan','purple']

# taille de histogramme en % de la taille de schema_flux.gif
histo_largeur=1
histo_hauteur=10

# taille affichage valeur
texte_dy=3
texte_dx=10
texte_x0=15
texte_y0=100
texte_ymax=140

##################################################
# fonctions

def normacoord(x1,y1) :
    x2=x1*ni_fig/100
    y2=y1*nj_fig/100
    return [x2,y2]

def fait_histo(x0,y0,val,val_max,leg,pos_leg,liste_couleurs) :
    # pos_leg : position de la legende =h/b/g/d pour
    #           haut,bas,gauche,droite des histogrammes
    if pos_leg in ['h','b','g'] : x_leg=x0
    if pos_leg in ['b','g','d'] : y_leg=y0
    nb_histo=len(val)
    for i in range(nb_histo) :
        signe=val[i]/abs(val[i])
        x1=x0+histo_largeur
        y1=y0-histo_hauteur/val_max*abs(val[i])*signe
        coord_bas_gauche=normacoord(x0,y0)
        cooord_haut_droit=normacoord(x1,y1)
        xx0,yy0=coord_bas_gauche
        xx1,yy1=cooord_haut_droit
        base.create_rectangle(xx0,yy0,xx1,yy1,fill=liste_couleurs[i])
        x0=x1
    if pos_leg in ['d'] : x_leg=x0+2*histo_largeur
    if pos_leg in ['h'] : y_leg=y_leg+histo_hauteur
    xx0,yy0=normacoord(x_leg,y_leg)
    if leg != '' : base.create_text(xx0,yy0,text=leg,fill='black')


def affiche_etiquette(etiquette,liste_couleurs) :
    # routine qui affiche la liste de run en haut au centre
    x=50
    y=10
    dy=3
    for i in range(len(etiquette)) :
        xx0,yy0=normacoord(x,y)
        base.create_text(xx0,yy0,text=etiquette[i],fill=liste_couleurs[i],anchor=NW)
        y=y+dy
                         


def affiche_valeur(etiquette,val,titre,liste_couleurs) :
    # routine qui affiche la liste des champs et leur valeurs pour les differentes runs
    global x_texte
    global y_texte
    nb_val=len(val)
    xx0,yy0=normacoord(x_texte,y_texte)
    base.create_text(xx0,yy0,text=titre,fill='black')
    y_texte=y_texte+texte_dy
    if y_texte > texte_ymax :
        x_texte=x_texte+texte_dx
        y_texte=texte_y0
    for i in range(nb_val) :
        #texte="%10s %10.4f" % (etiquette[i],val[i])
        texte="%10.4f" % val[i]
        xx0,yy0=normacoord(x_texte,y_texte)
        base.create_text(xx0,yy0,text=texte,fill=liste_couleurs[i])
        y_texte=y_texte+texte_dy
        if y_texte > texte_ymax :
           x_texte=x_texte+texte_dx
           y_texte=texte_y0
    
##################################################
# lecture de l'input

# lecture du nom du fichier contenant les stats
for a in range(len(sys.argv)) :
    if a>0 :
        if sys.argv[a] == '-fichier' :
            fichier=sys.argv[a+1]
            print 'en argument, -fichier=',fichier
    else :
        fichier='stat_ascii'

serie_flux=[]
f=open(fichier)
compteur=0
while 1:
    ligne=f.readline()
    if not ligne : break
    # on split la ligne
    champ,val=string.split(ligne,':')
    champ=string.strip(champ)
    val=string.strip(val)
    if champ == 'RUN' :
        # nouvelle run
        compteur=compteur+1
        # s'il y deja un flux on l'additionne a la serie
        if compteur > 1 : serie_flux.append(flux)
        # on initialise le flux
        flux={}
        flux['couleur']=liste_couleurs[compteur-1]
        flux[champ]=val
    else :
        flux[champ]=float(val)

# on ajoute les derniers flux lu a la serie
if compteur > 0 : serie_flux.append(flux)

print 'serie_flux=',serie_flux

##################################################
# dessin

root=Tk()
root.title('flux')
# ajout du fond

base=Canvas(root,height=nj_max,width=ni_max)
pic=PhotoImage(file=fond)
base.create_image(0,0,image=pic,anchor=NW)

# affichage du fichier traite

xx0,yy0=normacoord(50,5)
base.create_text(xx0,yy0,text=fichier)

# affichage des runs traites
run=[]
couleurs=[]
for f in serie_flux :
    run.append(f['RUN'])
    couleurs.append(f['couleur'])
affiche_etiquette(run,couleurs)


# boucle sur les champs a afficher
#champs_affiches=['FSR','FSO','FSA','CLDT','FLA','FSS','MST4','FDL','FLAG','FSG','GT','FLG','HFS','QFS','BEG']
champs_affiches=['FSR','FSO','FSA','CLDT','FLA','FSS','MST4','FDL','FLAG','FSG','ST','FLG','HFS','QFS','BEG']
coord_histo={'FSR' : (5,20), 'FSO':(30,20),'FSA':(10,50),'CLDT':(50,50),'FLA':(85,40),
             'FSS':(25,75),'MST4':(65,65),'FDL':(85,70),'FLAG':(85,10),
             'FSG':(10,90),'GT':(45,70),'FLG':(85,80),'HFS':(35,70),'QFS':(55,70),'BEG':(10,70),
             'ST':(45,70)}

x_texte=texte_x0
y_texte=texte_y0

for c in champs_affiches :
    etiquettes=[]
    valeurs=[]
    couleurs=[]
    for flux in serie_flux :
        if flux.has_key(c) :
            etiquettes.append(flux['RUN'])
            valeurs.append(flux[c])
            couleurs.append(flux['couleur'])
            
    # ajustement de la valeur maximal pour les histogrammes
    if c == 'CLDT' : val_max=1
    # on passe en W/m**2 pour QFS
    if c == 'QFS' :
        bidon=[]
        for v in valeurs :
            bidon.append(v*2.5E6)
        valeurs=bidon
        val_max=max(map(abs,valeurs))
    # on passe en C pour GT
    if c in ['GT','ST'] :
        bidon=[]
        for v in valeurs :
            bidon.append(v-273.)
        valeurs=bidon
        val_max=max(map(abs,valeurs))
    else :
        val_max=max(map(abs,valeurs))
        print 'pour champs ',c
        print 'val_max=',val_max
        

    if len(etiquettes) > 0 :
        x0,y0=coord_histo[c]
        # on fait l'histogramme
        fait_histo(x0,y0,valeurs,val_max,c,'d',couleurs)
        # on affiche les valeurs
        affiche_valeur(etiquettes,valeurs,c,couleurs)


base.pack()
base.postscript(file=fichier+'.ps',x=0,y=0,width=ni_max,height=nj_max)
os.system('convert -geometry 90% '+fichier+'.ps toto.ps')
os.system('mv toto.ps '+fichier+'.ps')

print 'Le fichier '+fichier+'.ps a ete cree'


root.mainloop()
