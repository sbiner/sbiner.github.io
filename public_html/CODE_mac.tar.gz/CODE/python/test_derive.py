# petit test pour faire un programme qui derive des fonctions


liste_operateurs=[]
liste_operateurs.append(['+','-'])
liste_operateurs.append(['*','/'])
liste_operateurs.append(['^'])

def trouve_operateur(terme) :
    import string
    operateur=0
    for liste_op in liste_operateurs :
##        print 'on cherche dans ',liste_op
        for op in liste_op :
            ###print 'on cherche ',op
            index=string.find(terme,op)
            if index != -1 :
                operateur=op
                terme1=terme[0:index]
                terme2=terme[index+1:]
                break
            ###print 'on n\'a pas trouve ',op
        if operateur :
            ###print 'operateur trouve'
            break
            
    if not operateur :
        ###print 'aucun operateur trouve'
        operateur=terme
        terme1=''
        terme2=''
        
##     print '*********************'
##     print '*** trouve operateur ***'
##     print 'terme=',terme
##     print 'operateur=',operateur
##     print 'terme1=',terme1
##     print 'terme2=',terme2
##    print '*********************'
    return operateur,terme1,terme2

    
def est_un_nombre(x) :
    sortie=1
    try:
        float(x)
    except ValueError :
        sortie=0
    return sortie


def derive(terme,var) :
    import string
    op,terme1,terme2=trouve_operateur(terme)
    # cas + -
    if op == '+' : sortie=derive(terme1,var)+'+'+derive(terme2,var)
    elif op == '-' : sortie=derive(terme1,var)+'-'+derive(terme2,var)
    # cas * /
    elif op == '*' : sortie=derive(terme1,var)+'*'+terme2+'+'+terme1+'*'+derive(terme2,var)
    elif op == '/' : sortie='('+derive(terme1,var)+'*'+terme2+'-'+terme1+'*'+derive(term2,var)+ \
         ')/('+terme2+')^2'
    # cas ^
    elif op == '^' : sortie=terme2+'*'+'('+terme1+')^('+terme2+'-1)*'+derive(terme1,var)
    # cas ou on est rendu a la variable
    elif op == var : sortie='1'
    # cas d'une fonction de la variable qu'on ne sait pas traiter
    elif string.find(op,var) != -1 : sortie='('+op+')\''
    # cas d'une constante
    elif est_un_nombre(op) : sortie='0'
    # cas d'une autre variables ou d'une fonction
    else : sortie='('+op+')\''

    return sortie

def simplifie(terme) :
    op,terme1,terme2=trouve_operateur(terme)
    if op != terme :
        sortie=simplifie(terme1)+op+simplifie(terme2)
        # on enleve les terme nuls dans une somme/soustraction
        if op in ['+','-'] :
            if terme1 in ['0',''] : sortie=simplifie(terme2)
            if terme2 in ['0',''] : sortie=simplifie(terme1)
            if terme1 in ['0',''] and terme2 in ['0',''] : sortie=''
        # on enleve les multiplication par 0
        if op == '*' :
            if terme1 == '0' or terme2 == '0' : sortie=''
        # on enlevve les */ par 1
        if op in ['*','/'] :
            if terme1 == '1' : sortie=simplifie(terme2)
            if terme2 == '1' : sortie=simplifie(terme1)
        # si les deux termes sont des chiffres on peut faire le calcule
        if est_un_nombre(terme1) and est_un_nombre(terme2) :
            cmd=terme1+op+terme2
            sortie=eval(cmd)


    else : sortie=terme
    
    return sortie


equ='2*x^2+3*u'
var='x'

derivee=derive(equ,var)
derivee2=derivee

while derivee2 != simplifie(derivee2) :
    derivee2=simplifie(derivee2)

print 'equation=',equ
print 'var=',var
print 'derivee=',derivee
print 'derivee simplifiee',derivee2
