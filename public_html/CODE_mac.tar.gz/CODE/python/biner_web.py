from HTMLgen import *

class Entete(SimpleDocument) :

    def __init__(self) :
        self.contents=[]
        
        # on met l'ancre vers cette partie de la page
        self.append(Name('entete'))
        self.lien_vers_entete=Href('#entete',Font('retour en haut',size='-1'))

        # affichage de la derniere mise a jour
        font_maj=Font(size='-1')
        texte_maj='derniere mise a jour:'+time.strftime('%d/%m/%Y %Hh%M',time.localtime())
        font_maj.append(texte_maj)
        self.append(Paragraph(font_maj,align='right'))

        # on prepare la liste des liens contenus dans l'entete
        self.liste_liens=List()
    
    def ajoute_lien_entete(self,lien) :
        """
        methode pour ajouter un lien a la liste de lien contenu dans l'entete
        """
        self.liste_liens.append(lien)

    def termine(self) :
        """
        methode qui ajoute la liste de lien dans l'entete. Methode a mettre une foi l'entete terminee
        """
        self.append(self.liste_liens)
                    
