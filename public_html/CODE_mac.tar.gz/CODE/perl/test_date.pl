#! /usr/bin/perl

BEGIN {
   push ( @INC, '/expl/biner/INFO/perl_extra/lib' );
}

###use lib '/expl/biner/INFO/perl_extra/lib' ;
use Date::Manip ;

#use Date::Manip

#$date=ParseDate("today"); 

#print,$date ;	 
 
print "@INC";

