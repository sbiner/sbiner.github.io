#! /usr/bin/perl

use CGI qw/:standard/ ;

##################################################

# programme pour generer les page web de diagnostique
# automatiquement

##################################################
#
# parametres du script

$montre_sortie_tidy=0 ; # affiche les sortie de tidy a l'ecran

# declaration des variables de base

$web_base="http://rhea.ouranos.ca/~biner/diag_mrc" ;
#$web_base="/rhea/biner/perl/test" ;
$rep_base="/rhea/biner/public_html/diag_mrc" ;
$index="index.html" ;
$liste_run="liste_run.html" ;
$accueil="accueil.html" ;
$coin="coin.html" ;
$entete_init="entete_init.html" ;


@liste_run=(aaa,aab,aac,aad,aae) ;


# on genere la page index
&fait_index() ;
# on genere la page de liste de run
&fait_liste_run() ;
# on genere le coin haut gauche
&fait_coin() ;
# on genere l'entete initiale
&fait_entete_init() ;

# on genre la page d'accueil
&fait_accueil() ;
# on genere le menu de ce qui est disponible pour chaque simulation
###foreach $n (@liste_run) {
&fait_menu($liste_run[0]) ;
###}

##################################################
# sous-routine pour ouvrir des fichiers dans $rep_base
#
# arguments : #0 s numero de l<unite du fichier
#             #1 e nom du fichier
# 
# le fichier est ouvert dans le repertoire $rep_base et le numero
# d'unite est contenu dans l'argument 0

sub ouvre_fichier{
	 open ($_[0],">$rep_base\/$_[1]") || print "ne peut ouvrir fichier $rep_base\/$_[1]\n" ; 
}

##################################################
# sous-routine qui fait la page $coin

sub fait_coin {
	 # on ouvre le fichier de sortie et on  y redirige le STDOUT
	 &ouvre_fichier(code_coin,$coin) ;
	 $vieux_fh = select(code_coin) ;
	 
	 # on genere un objet CGI
	 $toto = new CGI ;

	 # on ecrit le debut du fichier
	 print $toto->a({-href=>$web_base,-target=>_top},h1("DIAG MRC")) ;

	 # on redirige les sorties vers STDOUT
	 select($vieux_fh) ;
	 close(code_coin) ;

	 # on valide la page
	 &valide_html($coin) ;

}

##################################################
# sous-routine qui fait la page entete_init

sub fait_entete_init {
	 # on ouvre le fichier de sortie et on  y redirige le STDOUT
	 &ouvre_fichier(code_entete_init,$entete_init) ;
	 $vieux_fh = select(code_entete_init) ;
	 
	 # on genere un objet CGI
	 $toto = new CGI ;

	 # on ecrit le debut du fichier
	 print $toto->h1("site des diags du MRCC") ;
	 $maintenant=`date`;
	 print $toto->p("derniere mise a jour $maintenant") ;


	 # on redirige les sorties vers STDOUT
	 select($vieux_fh) ;
	 close(code_entete_init) ;

	 # on valide la page
	 &valide_html($entete_init) ;

}

##################################################
# sous-routine qui fait la page $index
#
# le fichier produit est definie par la variable $index

sub fait_index {
	 # on ouvre le fichier de sortie et on y redirige le STDOUT
	 &ouvre_fichier(code_index,$index) ;
	 $vieux_fh = select(code_index) ;

	 # on genere un objet CGI
	 $toto = new CGI ;

	 # on ecrit le debut du fichier

	 print $toto->head($toto->title('DIAG DU MRCC')) ;

	 # on ecrit le frameset

	 print $toto->frameset({-cols=>'100,*'},
								  $toto->frameset({-rows=>'75,*'},
														$toto->frame({-src=>$coin,-frameborder=>0,-scrolling=>'no'}),
														$toto->frame({-src=>$liste_run,frameborder=>0,-scrolling=>'no'})
														),
								  $toto->frameset({-rows=>'75,*'},
														$toto->frame({-src=>$entete_init,-name=>entete,-frameborder=>0}),
														$toto->frame({-src=>$accueil,-name=>affichage,-scrolling=>auto,-frameborder=>0})
														)
								  );
	 select($vieux_fh) ;
	 close(code_index) ;
	 
	 # on valide la page
	 &valide_html($index) ;
	 
}

##################################################
# sous-routine qui fait la page $liste_run
#
# cette page apparait dans la colonne de gauche de la page index
#
# le fichier produit est definie par la variable $liste_run

sub fait_liste_run{

	 # on ouvre le fichier de sortie et on redirige le STDOUT
	 &ouvre_fichier (code_liste_run,"$liste_run") ;
	 $vieux_fh = select(code_liste_run) ;

	 # on genere un objet CGI
	 $toto = new CGI ;

	 # on genere la colonne contenant toutes les runs
	 foreach $n (@liste_run) {
		  push (@colonne,Tr(td(a({-href=>"menu/$n.html",-target=>"affichage"},$n)))) ;
	 }

	 print $toto->h2("liste des runs") ;
	 print $toto->hr() ;
	 print $toto->table(	 
							  @colonne 
							  ) ;

	 # on redirige les sorties vers STDOUT
	 select($vieux_fh) ;
	 close(code_liste_run) ;

	 # on valide la page
	 &valide_html($liste_run) ;
}

##################################################
# sous-routine qui genere la page d'accueil
#
# cette page est la page qui apparait par defaut dans la partie
# de droite de la page principale.
#
# le fichier produit est define par la variable $accueil


sub fait_accueil{
	 # on ouvre le fichier de sortie et on redirige le STDOUT
	 &ouvre_fichier (code_accueil,"$accueil") ;
	 $vieux_fh = select(code_accueil) ;

	 print $toto->h1("Bienvenue sur le site d'analyses des simulations du MRCC");
	 print $toto->hr() ;
	 print $toto->p("choisissez une simulation dans la colonne de droite et un 
                    menu des analyses dispnible apparaitra") ;
                    
	 # on redirige les sorties vers STDOUT
	 select($vieux_fh) ;
	 close(code_accueil) ;

	 # on valide la page
	 &valide_html($accueil) ;
}

##################################################
# sous-routine pour dresser le menu de ce qui est disponible
# pour une simulation donnee.
# 
# arguments : #0 nom de la simulation pour laquelle on veut faire le menu
#
# En faisant le menu, la sous-routine produit toutes les pages disponibles
#
# le fichier produit se nomme menu/$nom_run.html

sub fait_menu() {
	 $nom_run=$_[0] ; # nom de la run pour laquelle on fait le menu
	 
	 @liste_variable=qw(st stmx stmn pcp qfs cldt sno olr) ;
	 @liste_saison=qw(djf mam jja son) ;
	 
	 # on genere l'entete du tableau du menu
	 
	 @ligne1=th({-rowspan=>2,-width=>'20%'},'Variable') ;
	 push(@ligne1,th({-rowspan=>2,-width=>'10%'},'Annee complete')) ;
	 push(@ligne1,th({-colspan=>4},'Saison')) ;
	 push(@ligne1,th({-colspan=>2},'Diagramme')) ;

	 @ligne2=th({-width=>'10%'},[@liste_saison,'BLT','Taylor']) ;

	 # on genere le reste du tableau selon ce qui est disponible pour une run
	 # et une variable donnee

	 foreach $v (@liste_variable) {
		  # on debute la ligne du tableau avec le nom de la variable
		  @ligne=th($v) ;
		  # on va cherher ce qui est disponible pour la variable et la run
		  @etiquette=qw(annuelle djf mam jja son blt taylor) ;
		  @disponibilite=&disponibilite_menu($nom_run,$v) ;
		  # traitement de chaque cellule de la ligne
		  $longueur=@etiquette ;
		  for ($n=0;$n<$longueur;$n++){
				if ($disponibilite[$n]==1) {
					 $classe='dispo' ;
					 $page="$nom_run\/"."$v"."_"."$nom_run"."_"."$etiquette[$n]".".html" ;
					 $cellule=td({-align=>'center'},b({-class=>$classe},a({-href=>"../$page"},X))) ;
					 # on genere la page vers laquelle on fait le lien
					 &fait_page_produit($v,$nom_run,$etiquette[$n],$page) ;
				}
				else {
					 $classe='non_dispo' ;
					 $cellule=td({-align=>'center'},b({-class=>$classe},X)) ;
				}
		  		  # on ajoute la cellule a la ligne de la variable
				push(@ligne,$cellule)	;
		  }
		  # on ajoute la ligne au tableau
		  push(@tableau,Tr(@ligne)) ;
	 }

	 # on ouvre le fichier de sortie et on redirige le STDOUT
	 &ouvre_fichier (code_menu,"/menu/$nom_run.html") ;
	 $vieux_fh = select(code_menu) ;
	 
	 # on inclut le fichier de style
	 print '<link type="text/css" rel="stylesheet" href="../style.css">' ;

	 # on genere un objet CGI
	 $toto = new CGI ;
	 
	 # on ecrit le tableau
	 print $toto->head($toto->title("menu pour la simulation $nom_run")) ;

	 print $toto->h2("menu pour la simulation $nom_run") ;
	 print $toto->hr() ;
	 print $toto->h3("moyenne") ;
	 print $toto->table({-align=>'center',-width=>'80%',-border=>'1'},
							  Tr({-align=>'center'},@ligne1),
							  Tr({-align=>'center'},@ligne2),
							  ###Tr({-align=>'center'},@tableau) 
							  @tableau
							  );

	 # on redirige les sorties vers STDOUT
	 select($vieux_fh) ;
	 close(code_menu) ;

	 # on valide le code html
	 &valide_html("/menu/$nom_run.html") ;
}

##################################################
# fonction qui retourne la liste de ce qui est disponible
# pour une run et une variables donnees.
#
# arguments #0 e nom de la run
#           #1 e variable
#
# cette fonction retourne un tableau rempli de 0 et de 1 qui indique
# ce qui est disponible pour une simulation donnee et une variable
# donnee.


sub disponibilite_menu {
	 $run=$_[0] ; # run
	 $var=$_[1] ; # variable
	 
	 $n_col=7 ;

	 # il y a un produit par colonne
	 # 0 : moyenne annuelle
	 # 1 : moyenne DJF
	 # 2 : moyenne MAM
    # 3 : moyenne JJA
	 # 4 : moyenne SON
	 # 5 : diag BLT
	 # 6 : diag Taylor

	 for ($n=0 ; $n < $n_col ; $n++) {
		  if ($n == 0 or $n  == 6) {
				@disponibilite[$n]=1 ;
		  }
		  else {
				@disponibilite[$n]=0 ;
		  }
	 }
	 return @disponibilite ;
	 
}

##################################################
# sous routine qui genere les pages contenant les graphiques

sub fait_page_produit {

	 # on force la declaration des variables locales pour eviter les problemes
	 #use strict ;
 	 my($variable,$nom_run,$etiquette,$page,$n) ;
	 my (@image,$nb_image,$cellule,@cellule,$toto,$code_produit) ;
	 
	 # on decode les arguements
	 $variable=$_[0] ;
	 $nom_run=$_[1] ;
	 $etiquette=$_[2] ;
	 $page=$_[3] ;
	 
	 # on prepare la page

	 $rep_images='../images' ;
 	 @image=qw(ST_AAQAALME.gif ST_AAQAALMF.gif ST_AAQAALMH.gif ST_AAQAALMP.gif);


 	 # on genere les cellules
 	 $nb_image=@image ;
 	 for ($n=0;$n<$nb_image;$n++) {
		  $label=`basename $image[$n]` ;
		  
		  $source_image=$rep_images . '/' . $image[$n] ;

 		  $cellule=td($label,a({-href=>$source_image},img({-src=>$source_image,-width=>'100%'}))) ;
 		  push (@cellule,$cellule) ;
 	 }

	 # on ouvre le fichier de sortie et on redirige le STDOUT
 	 &ouvre_fichier(code_produit,$page) ;
 	 $vieux_fh = select(code_produit) ;

 	 # on genere un objet CGI
 	 $toto = new CGI ;

 	 print $toto->h1("test de graphique") ;
	 print $toto->table({-cellspacing=>'10',-width=>'100%'},
							  Tr($cellule[0],$cellule[1]),
							  Tr($cellule[2],$cellule[3])
							  ) ;

 	 # on redirige les sorties vers STDOUT
 	 select($vieux_fh) ;
 	 close(code_produit) ;

	 # on valide le html
	 &valide_html($page) ;

}

##################################################
# sous-routine qui valide une page web avec l'utilitaire tidy
#
# entree : fichier
# sortie : fichier : fichier modifie par tidy

sub valide_html {
	 $fichier="$rep_base/$_[0]" ;
###	 system(" $fichier ${fichier}_v") ;
	 if ($montre_sortie_tidy == 0) {
		  system("/rhea/biner/bin/tidy -o $fichier ${fichier} > /dev/null 2>\&1" ) ;
	 } else {
		  print "**************************************************\n";
		  print "MESSAGE DE TIDY POUR FICHIER $fichier \n" ;
		  print "**************************************************\n";
		  system("/rhea/biner/bin/tidy -o $fichier ${fichier}" ) ;
		  print "**************************************************\n";
	 }

}
